const model={
 summary:{batches:1245,groups:86,issueBatches:98,critical:21,failures:4892,expected:12840000,matched:11920000,missed:920000,matchRate:92.82},
 trend:[
  {day:'Aug 25',issues:9,failures:421},{day:'Aug 26',issues:12,failures:566},{day:'Aug 27',issues:14,failures:738},
  {day:'Aug 28',issues:11,failures:629},{day:'Aug 29',issues:18,failures:902},{day:'Aug 30',issues:16,failures:771},{day:'Aug 31',issues:18,failures:865}
 ],
 groups:[
  {id:'600000001',name:'Australia IFTI',country:'Australia',batches:38,issues:4,expected:1284300,matched:1279912,missed:4388,failures:27,recon:3,health:'Critical',owner:'APAC Operations'},
  {id:'600000007',name:'US SAR',country:'United States',batches:49,issues:3,expected:3401250,matched:3399842,missed:1408,failures:12,recon:2,health:'Warning',owner:'Americas Operations'},
  {id:'600000011',name:'UK SAR',country:'United Kingdom',batches:31,issues:1,expected:876340,matched:876328,missed:12,failures:2,recon:1,health:'Warning',owner:'EMEA Operations'},
  {id:'600000015',name:'Norway Objective',country:'Norway',batches:12,issues:1,expected:12,matched:0,missed:12,failures:0,recon:1,health:'Critical',owner:'EMEA Operations'},
  {id:'600000023',name:'Canada LCTR',country:'Canada',batches:44,issues:0,expected:928442,matched:928442,missed:0,failures:0,recon:0,health:'Healthy',owner:'Americas Operations'}
 ],
 batches:[
  {id:'B-20260818-137',rgId:'600000001',rg:'Australia IFTI',run:'18 Aug 2026 14:07',seq:2,expected:8421,actual:8379,diff:-42,selected:8518,lookback:714,lookbackActual:702,lookbackFuture:12,period:7792,periodActual:7770,periodFuture:22,simulated:12,eligible:8397,transformed:8377,failed:18,duplicate:2,balance:0,missing:3,excluded:61,already:32,activityMissing:4,dedup:2,recon:-42,health:'Critical',owner:'APAC Operations',state:'Investigating',age:'1h 18m'},
  {id:'B-20260816-094',rgId:'600000007',rg:'US SAR',run:'16 Aug 2026 09:12',seq:1,expected:12408,actual:12399,diff:-9,selected:12501,lookback:911,lookbackActual:904,lookbackFuture:7,period:11586,periodActual:11573,periodFuture:13,simulated:4,eligible:12421,transformed:12412,failed:7,duplicate:2,balance:0,missing:1,excluded:54,already:38,activityMissing:2,dedup:1,recon:-9,health:'Warning',owner:'Americas Operations',state:'Assigned',age:'3h 44m'},
  {id:'B-20260815-051',rgId:'600000015',rg:'Norway Objective',run:'15 Aug 2026 03:21',seq:1,expected:12,actual:0,diff:-12,selected:12,lookback:0,lookbackActual:0,lookbackFuture:0,period:12,periodActual:12,periodFuture:0,simulated:0,eligible:12,transformed:12,failed:0,duplicate:0,balance:0,missing:0,excluded:0,already:0,activityMissing:0,dedup:0,recon:-12,health:'Critical',owner:'EMEA Operations',state:'Escalated',age:'6h 09m'},
  {id:'B-20260814-084',rgId:'600000011',rg:'UK SAR',run:'14 Aug 2026 08:42',seq:3,expected:7044,actual:7042,diff:-2,selected:7108,lookback:488,lookbackActual:482,lookbackFuture:6,period:6618,periodActual:6608,periodFuture:10,simulated:2,eligible:7053,transformed:7051,failed:2,duplicate:0,balance:0,missing:0,excluded:41,already:23,activityMissing:0,dedup:0,recon:-2,health:'Warning',owner:'EMEA Operations',state:'Monitoring',age:'45m'},
  {id:'B-20260812-128',rgId:'600000001',rg:'Australia IFTI',run:'12 Aug 2026 13:55',seq:1,expected:8192,actual:8192,diff:0,selected:8261,lookback:692,lookbackActual:686,lookbackFuture:6,period:7561,periodActual:7554,periodFuture:7,simulated:8,eligible:8192,transformed:8192,failed:0,duplicate:0,balance:0,missing:0,excluded:47,already:22,activityMissing:0,dedup:0,recon:0,health:'Healthy',owner:'APAC Operations',state:'Closed',age:'—'},
  {id:'B-20260811-077',rgId:'600000007',rg:'US SAR',run:'11 Aug 2026 07:18',seq:2,expected:11904,actual:11900,diff:-4,selected:11983,lookback:846,lookbackActual:840,lookbackFuture:6,period:11133,periodActual:11120,periodFuture:13,simulated:4,eligible:11911,transformed:11907,failed:4,duplicate:0,balance:0,missing:0,excluded:46,already:26,activityMissing:0,dedup:0,recon:-4,health:'Warning',owner:'Americas Operations',state:'Assigned',age:'2h 10m'}
 ],
 txns:[
  {mtcn:'4839201756',batch:'B-20260818-137',rgId:'600000001',rg:'Australia IFTI',rule:'AU-IFTI-017',stage:'Transformation',status:'Failed',reason:'Invalid beneficiary country code',reported:'No',excluded:'No',exclusionReason:'—',strategy:'—',external:'EXT-AU-9182741',attempt:'ATT-782104',galactic:'GL-2290184',time:'18 Aug 2026 14:07:09'},
  {mtcn:'4839202811',batch:'B-20260818-137',rgId:'600000001',rg:'Australia IFTI',rule:'AU-IFTI-004',stage:'Reporting',status:'Completed',reason:'—',reported:'Yes',excluded:'No',exclusionReason:'—',strategy:'—',external:'EXT-AU-9182811',attempt:'ATT-782122',galactic:'GL-2290212',time:'18 Aug 2026 14:08:11'},
  {mtcn:'4839203390',batch:'B-20260818-137',rgId:'600000001',rg:'Australia IFTI',rule:'AU-IFTI-011',stage:'Selection',status:'Skipped',reason:'Already reported',reported:'No',excluded:'Yes',exclusionReason:'Already reported',strategy:'Prior reporting check',external:'EXT-AU-9183390',attempt:'ATT-782141',galactic:'GL-2290240',time:'18 Aug 2026 14:08:42'},
  {mtcn:'4839204412',batch:'B-20260818-137',rgId:'600000001',rg:'Australia IFTI',rule:'AU-IFTI-017',stage:'Transformation',status:'Failed',reason:'Missing sender occupation',reported:'No',excluded:'No',exclusionReason:'—',strategy:'—',external:'EXT-AU-9184412',attempt:'ATT-782188',galactic:'GL-2290301',time:'18 Aug 2026 14:09:03'},
  {mtcn:'7741200933',batch:'B-20260816-094',rgId:'600000007',rg:'US SAR',rule:'US-SAR-022',stage:'Transformation',status:'Failed',reason:'Invalid party address structure',reported:'No',excluded:'No',exclusionReason:'—',strategy:'—',external:'EXT-US-1200933',attempt:'ATT-680214',galactic:'GL-3191042',time:'16 Aug 2026 09:13:08'},
  {mtcn:'7741201120',batch:'B-20260816-094',rgId:'600000007',rg:'US SAR',rule:'US-SAR-006',stage:'Reporting',status:'Completed',reason:'—',reported:'Yes',excluded:'No',exclusionReason:'—',strategy:'—',external:'EXT-US-1201120',attempt:'ATT-680233',galactic:'GL-3191094',time:'16 Aug 2026 09:13:29'},
  {mtcn:'6210045581',batch:'B-20260814-084',rgId:'600000011',rg:'UK SAR',rule:'UK-SAR-009',stage:'Transformation',status:'Failed',reason:'Required narrative field empty',reported:'No',excluded:'No',exclusionReason:'—',strategy:'—',external:'EXT-UK-0045581',attempt:'ATT-550241',galactic:'GL-4110298',time:'14 Aug 2026 08:43:12'},
  {mtcn:'6210045622',batch:'B-20260814-084',rgId:'600000011',rg:'UK SAR',rule:'UK-SAR-003',stage:'Reporting',status:'Completed',reason:'—',reported:'Yes',excluded:'No',exclusionReason:'—',strategy:'—',external:'EXT-UK-0045622',attempt:'ATT-550252',galactic:'GL-4110314',time:'14 Aug 2026 08:43:31'}
 ]
};

const params=new URLSearchParams(location.search);const $=s=>document.querySelector(s);const $$=s=>[...document.querySelectorAll(s)];
const fmt=n=>Number(n).toLocaleString('en-US');const pct=(a,b)=>b?`${(100*a/b).toFixed(2)}%`:'—';
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const qref=q=>`<a class="qref" href="query-detail.html?id=${q}">${q}</a>`;
const health=h=>`<span class="badge ${h==='Critical'?'critical':h==='Warning'?'warning':h==='Healthy'?'healthy':'info'}">${esc(h)}</span>`;
const status=s=>`<span class="badge ${s==='Failed'?'critical':s==='Completed'||s==='Closed'?'healthy':s==='Skipped'?'warning':'info'}">${esc(s)}</span>`;
const groupUrl=id=>`report-group.html?id=${encodeURIComponent(id)}`;const batchUrl=id=>`batch-control-room.html?batch=${encodeURIComponent(id)}`;const txnUrl=id=>`transaction.html?mtcn=${encodeURIComponent(id)}`;

function bindRows(){
 $$('tr[data-href]').forEach(r=>{r.tabIndex=0;r.onclick=e=>{if(!e.target.closest('a,button'))location.href=r.dataset.href};r.onkeydown=e=>{if(e.key==='Enter')location.href=r.dataset.href}})
}
function showToast(text){let t=document.createElement('div');t.className='toast';t.textContent=text;document.body.append(t);setTimeout(()=>t.remove(),1700)}
function bindGlobal(){
 bindRows();
 $$('.tab').forEach(t=>t.onclick=()=>{$$('.tab,.tab-pane').forEach(x=>x.classList.remove('active'));t.classList.add('active');$(`#${t.dataset.tab}`)?.classList.add('active')});
 $$('[data-copy]').forEach(b=>b.onclick=async()=>{try{await navigator.clipboard.writeText(location.href);showToast('Link copied')}catch{showToast('Copy is unavailable in this browser')}});
 $$('[data-export]').forEach(b=>b.onclick=()=>exportTable(b.dataset.export));
 $$('[data-clear]').forEach(b=>b.onclick=()=>{let box=b.closest('.filters');box?.querySelectorAll('input,select').forEach(x=>{x.value=''});filterTable(b.dataset.clear||'data-table')});
 $$('[data-table-filter]').forEach(x=>{x.oninput=x.onchange=()=>filterTable(x.dataset.tableFilter)});
}
function filterTable(id){
 let table=$(`#${id}`);if(!table)return;let scope=table.closest('main')||document;let search=(scope.querySelector('[data-filter-search]')?.value||'').toLowerCase();let rg=scope.querySelector('[data-filter-rg]')?.value||'';let h=scope.querySelector('[data-filter-health]')?.value||'';let state=scope.querySelector('[data-filter-state]')?.value||'';let shown=0;
 table.querySelectorAll('tbody tr').forEach(r=>{let text=r.innerText.toLowerCase(),ok=(!search||text.includes(search))&&(!rg||r.dataset.rg===rg)&&(!h||r.dataset.health===h)&&(!state||r.dataset.state===state);r.classList.toggle('hidden',!ok);if(ok)shown++});
 $('[data-visible-count]')&&( $('[data-visible-count]').textContent=`${shown} shown` );
}
function exportTable(id){
 let table=$(`#${id}`);if(!table)return;let csv=[...table.querySelectorAll('tr:not(.hidden)')].map(r=>[...r.children].map(c=>`"${c.innerText.replaceAll('"','""')}"`).join(',')).join('\n');let a=document.createElement('a');a.href=URL.createObjectURL(new Blob([csv],{type:'text/csv'}));a.download=`compliance-${id}.csv`;a.click();URL.revokeObjectURL(a.href);showToast('CSV exported')
}
function batchRow(b){return `<tr data-href="${batchUrl(b.id)}" data-rg="${esc(b.rg)}" data-health="${b.health}" data-state="${b.state}"><td><a class=link href="${batchUrl(b.id)}">${b.id}</a><br><small>seq ${b.seq}</small></td><td><a class=link href="${groupUrl(b.rgId)}">${b.rg}</a></td><td>${b.run}</td><td class="num ${b.diff?'danger':''}">${b.diff}</td><td class=num>${b.missing}</td><td class=num>${b.failed}</td><td>${health(b.health)}</td><td>${status(b.state)}</td><td>${b.owner}</td></tr>`}
function groupRow(g){return `<tr data-href="${groupUrl(g.id)}" data-rg="${esc(g.name)}" data-health="${g.health}"><td><a class=link href="${groupUrl(g.id)}">${g.name}</a><br><small>${g.country}</small></td><td class=num>${g.batches}</td><td class="num ${g.issues?'danger':''}">${g.issues}</td><td class=num>${fmt(g.expected)}</td><td class=num>${fmt(g.matched)}</td><td class="num ${g.missed?'danger':''}">${fmt(g.missed)}</td><td class=num>${pct(g.matched,g.expected)}</td><td class=num>${g.failures}</td><td>${health(g.health)}</td></tr>`}
function txnRow(t){return `<tr data-href="${txnUrl(t.mtcn)}" data-rg="${esc(t.rg)}" data-state="${t.status}"><td><a class=link href="${txnUrl(t.mtcn)}">${t.mtcn}</a></td><td><a class=link href="${batchUrl(t.batch)}">${t.batch}</a></td><td>${t.rg}</td><td>${t.rule}</td><td>${t.stage}</td><td>${status(t.status)}</td><td>${t.reason}</td><td>${t.reported}</td><td>${t.excluded}</td></tr>`}

function renderOverview(){
 if(document.body.dataset.page!=='overview')return;
 $('#report-group-rows').innerHTML=model.groups.map(groupRow).join('');
 $('#priority-batch-rows').innerHTML=model.batches.filter(b=>b.health!=='Healthy').map(batchRow).join('');
 renderTrendChart('#trend-issues','issues','work-queue.html?view=issues','');
 renderTrendChart('#trend-failures','failures','work-queue.html?view=transformation-failures','failures');
 let ranked=model.groups.filter(g=>g.missed>0).sort((a,b)=>b.missed-a.missed),max=Math.max(...ranked.map(g=>g.missed));
 $('#missed-ranking').innerHTML=ranked.map(g=>`<a class=rank-row href="${groupUrl(g.id)}" aria-label="${g.name}: ${fmt(g.missed)} missed rule hits"><span class=rank-label>${g.name}</span><span class=rank-track><span class=rank-fill style="width:${100*g.missed/max}%"></span></span><span class="rank-value danger">${fmt(g.missed)}</span></a>`).join('');
}
function renderTrendChart(selector,key,url,barClass){let max=Math.max(...model.trend.map(d=>d[key]));$(selector).innerHTML=model.trend.map(d=>`<a class=trend-col href="${url}" aria-label="${d.day}: ${fmt(d[key])} ${key==='issues'?'issue batches':'transformation failures'}"><b>${fmt(d[key])}</b><span class="trend-bar ${barClass}" style="height:${Math.max(4,100*d[key]/max)}%"></span><small>${d.day.replace('Aug ','')}</small></a>`).join('')}

const queueModes={
 batches:{title:'All batch executions',subtitle:'Every latest-state batch execution in the selected operating period.',query:'Q001',tone:'info',definition:'One row per report group and batch, using the greatest seq_no after reprocessing.',question:'What ran, and what is its latest operational state?',next:'Open any batch to validate reportability, activity composition, transformation balance, and record evidence.'},
 issues:{title:'Batches requiring attention',subtitle:'The operational work queue for non-zero controls or processing exceptions.',query:'Q002',tone:'critical',definition:'Latest-state batches with a reportable difference, transformation failure, missing attempt, or transformation balance difference.',question:'Which executions need an operator now?',next:'Prioritize Critical first, then the oldest assigned Warning batch. Open the batch before assigning root cause.'},
 'transformation-failures':{title:'Transformation failure work queue',subtitle:'Record-level failures with a traceable journey and reason.',query:'Q003',tone:'critical',definition:'Journey records whose latest transformation status is Failed.',question:'Which records failed transformation, and why?',next:'Open a transaction, confirm its last successful stage, validate the source field, then decide whether to repair and reprocess.'},
 expected:{title:'Expected rule-hit coverage',subtitle:'Aggregate reporting obligations received from the IWRA control.',query:'Q004',tone:'info',definition:'SUM(distinct_rule_hits_count_iwra) for the selected period and report group.',question:'How many rule hits were expected?',next:'Compare expected with matched and missed by report group. Investigate groups with a non-zero missed count.'},
 matched:{title:'Matched rule-hit coverage',subtitle:'Aggregate expected rule hits reconciled on the Pharos side.',query:'Q004',tone:'info',definition:'SUM(distinct_rule_hits_count_pharos) for the selected period and report group.',question:'How many expected rule hits reconciled successfully?',next:'Use match rate to rank groups. Row-level reported evidence is available through rule_hit where a linked row exists.'},
 missed:{title:'Missed rule-hit reconciliation',subtitle:'Aggregate expected hits classified as missing by reconciliation logic.',query:'Q004',tone:'warning',definition:'SUM(missed_rule_hits_count_pharos). Validated control: Expected = Matched + Missed.',question:'Where is reporting coverage incomplete?',next:'Open the report group or a correlated batch. Do not claim a row-level list of expected-but-absent hits until its source table is validated.'}
};
function renderQueue(){
 if(document.body.dataset.page!=='queue')return;let key=params.get('view')||'issues',m=queueModes[key]||queueModes.issues;
 $('[data-queue-title]').textContent=m.title;$('[data-queue-subtitle]').textContent=m.subtitle;$('[data-queue-query]').innerHTML=qref(m.query);$('[data-queue-definition]').textContent=m.definition;$('[data-queue-question]').textContent=m.question;$('[data-queue-next]').textContent=m.next;
 let rows,heads,html;
 if(key==='transformation-failures'){rows=model.txns.filter(t=>t.status==='Failed');heads=['MTCN','Batch','Report group','Rule','Latest stage','Status','Reason','Reported','Excluded'];html=rows.map(txnRow).join('')}
 else if(['expected','matched','missed'].includes(key)){rows=key==='missed'?model.groups.filter(g=>g.missed>0):model.groups;heads=['Report group','Batches','Issue batches','Expected','Matched','Missed','Match %','Failures','Health'];html=rows.map(groupRow).join('')}
 else{rows=key==='issues'?model.batches.filter(b=>b.health!=='Healthy'):model.batches;heads=['Batch','Report group','Run time','Reportable diff','Missing attempts','Transform fail','Health','State','Owner'];html=rows.map(batchRow).join('')}
 $('#queue-head').innerHTML=heads.map(h=>`<th>${h}</th>`).join('');$('#queue-rows').innerHTML=html;$('[data-result-count]').textContent=fmt(rows.length);
 $('#queue-boundary').classList.toggle('hidden',key!=='missed');
}

function renderReportGroup(){
 if(document.body.dataset.page!=='report-group')return;let g=model.groups.find(x=>x.id===(params.get('id')||'600000001'))||model.groups[0],batches=model.batches.filter(b=>b.rgId===g.id);
 $$('[data-rg-name]').forEach(x=>x.textContent=g.name);$('[data-rg-country]').textContent=g.country;$('[data-rg-owner]').textContent=g.owner;$('[data-rg-health]').innerHTML=health(g.health);
 $('#rg-kpis').innerHTML=[['Batches',g.batches,'Q006'],['Issue batches',g.issues,'Q006'],['Expected hits',fmt(g.expected),'Q007'],['Matched hits',fmt(g.matched),'Q007'],['Missed hits',fmt(g.missed),'Q007'],['Match rate',pct(g.matched,g.expected),'Q007']].map(k=>`<div class=kpi><div class=label>${k[0]}</div><div class="value ${k[0]==='Missed hits'&&g.missed?'danger':''}">${k[1]}</div><div class=foot>${qref(k[2])}</div></div>`).join('');
 $('[data-coverage-expected]').textContent=fmt(g.expected);$('[data-coverage-matched]').textContent=fmt(g.matched);$('[data-coverage-missed]').textContent=fmt(g.missed);$('[data-coverage-match-bar]').style.width=`${g.expected?100*g.matched/g.expected:0}%`;$('[data-coverage-miss-bar]').style.width=`${g.expected?Math.max(2,100*g.missed/g.expected):0}%`;
 $('#rg-batch-rows').innerHTML=batches.length?batches.map(batchRow).join(''):`<tr><td colspan=9 class=empty>No mock batch executions are available for this report group.</td></tr>`;
 let misses=g.missed?`<div class="callout ${g.health==='Critical'?'critical':'warning'}"><strong>${fmt(g.missed)} missed rule hits require coverage review</strong>Start with reconciliation scope and correlated batch controls. Row-level expected-but-absent evidence remains an aggregate-only boundary.</div>`:`<div class="callout info"><strong>No missed rule hits in the selected period</strong>Continue monitoring processing controls and late reprocessing.</div>`;$('#rg-alert').innerHTML=misses;
}

function renderBatch(){
 if(document.body.dataset.page!=='batch')return;let b=model.batches.find(x=>x.id===(params.get('batch')||'B-20260818-137'))||model.batches[0],tx=model.txns.filter(t=>t.batch===b.id),hits=tx.filter(t=>t.reported==='Yes'||t.excluded==='Yes'),ex=tx.filter(t=>t.excluded==='Yes');
 $$('[data-batch-id]').forEach(x=>x.textContent=b.id);$$('[data-batch-rg]').forEach(x=>{x.textContent=b.rg;x.href=groupUrl(b.rgId)});$('[data-batch-meta]').textContent=`${b.rg} · ${b.run} · seq_no ${b.seq} (latest)`;$('[data-batch-health]').innerHTML=health(b.health);$('[data-batch-state]').innerHTML=status(b.state);$('[data-batch-owner]').textContent=b.owner;$('#batch-alert').className=`callout ${b.health==='Critical'?'critical':b.health==='Warning'?'warning':'info'}`;
 $('#reportability').innerHTML=metricControls([['Expected reportable',b.expected],['Actual reportable',b.actual],['Difference',b.diff]],b.diff?2:-1);
 $('#activity').innerHTML=`<div class=control><small>Activity selected</small><div class=big>${fmt(b.selected)}</div><p>Lookback <b>${fmt(b.lookback)}</b></p><p>Reporting period <b>${fmt(b.period)}</b></p><p>Simulated <b>${fmt(b.simulated)}</b></p></div><div class=control><small>Lookback</small><div class=big>${fmt(b.lookback)}</div><p>Actual ${fmt(b.lookbackActual)}</p><p>Future reporting ${fmt(b.lookbackFuture)}</p></div><div class=control><small>Reporting period</small><div class=big>${fmt(b.period)}</div><p>Actual ${fmt(b.periodActual)}</p><p>Future reporting ${fmt(b.periodFuture)}</p></div>`;
 $('#transformation').innerHTML=metricControls([['Eligible',b.eligible],['Transformed',b.transformed],['Failed',b.failed],['Duplicate',b.duplicate],['Balance difference',b.balance]],b.failed?2:-1);
 $('#exceptions').innerHTML=[['Missing attempts',b.missing],['Excluded transactions',b.excluded],['Already reported',b.already],['Activity missing',b.activityMissing],['Soft-dedup dropped',b.dedup],['Transformation failed',b.failed]].map(x=>`<div class=control><small>${x[0]}</small><div class="big ${x[1]&&['Missing attempts','Activity missing','Transformation failed'].includes(x[0])?'danger':''}">${fmt(x[1])}</div></div>`).join('');
 $('#journey-rows').innerHTML=tx.length?tx.map(txnRow).join(''):`<tr><td colspan=9 class=empty>No mock journey rows for this batch.</td></tr>`;
 $('#hit-rows').innerHTML=hits.length?hits.map(t=>`<tr data-href="${txnUrl(t.mtcn)}"><td><a class=link href="${txnUrl(t.mtcn)}">${t.mtcn}</a></td><td>${t.rule}</td><td>${t.reported==='Yes'?health('Healthy'):status('Skipped')}</td><td>${t.reported==='Yes'?'RB-'+b.id.slice(2):'—'}</td></tr>`).join(''):`<tr><td colspan=4 class=empty>No linked mock rule-hit rows.</td></tr>`;
 $('#exclusion-rows').innerHTML=ex.length?ex.map(t=>`<tr data-href="${txnUrl(t.mtcn)}"><td><a class=link href="${txnUrl(t.mtcn)}">${t.mtcn}</a></td><td>${t.rule}</td><td>${t.strategy}</td><td>${t.exclusionReason}</td><td>${t.time}</td></tr>`).join(''):`<tr><td colspan=5 class=empty>No linked exclusions for this batch.</td></tr>`;
 $('#tab-rulehits').classList.toggle('hidden',!hits.length);$('#tab-exclusions').classList.toggle('hidden',!ex.length);
 let cause=b.diff!==0?(b.failed?`${b.failed} record-level transformation failures explain part of the ${Math.abs(b.diff)}-record reportability difference; continue with the remaining exceptions.`:'Transformation balanced, but reporting coverage did not. Investigate the reconciliation boundary and publication state.'):'All displayed batch controls balance.';$('#batch-assessment').textContent=cause;
}
function metricControls(items,dangerIndex){return items.map((x,i)=>`<div class=control><small>${x[0]}</small><div class="big ${i===dangerIndex&&x[1]?'danger':x[0].includes('Balance')&&x[1]===0?'good':''}">${fmt(x[1])}</div>${i===dangerIndex&&x[1]?'<span class="badge critical">Control exception</span>':''}</div>`).join('')}

function renderTransaction(){
 if(document.body.dataset.page!=='transaction')return;let t=model.txns.find(x=>x.mtcn===(params.get('mtcn')||'4839201756'))||model.txns[0],b=model.batches.find(x=>x.id===t.batch);
 $$('[data-mtcn]').forEach(x=>x.textContent=t.mtcn);$$('[data-txn-batch]').forEach(x=>{x.textContent=t.batch;x.href=batchUrl(t.batch)});$$('[data-txn-rg]').forEach(x=>{x.textContent=t.rg;x.href=groupUrl(t.rgId)});$('[data-txn-status]').innerHTML=status(t.status);
 $('[data-root-class]').textContent=t.status==='Failed'?'Transformation failure':t.excluded==='Yes'?'Legitimate exclusion':'Completed reporting';$('[data-root-stage]').textContent=t.stage;$('[data-root-reason]').textContent=t.reason;$('[data-root-rule]').textContent=t.rule;
 $('[data-identifiers]').innerHTML=`<dt>MTCN</dt><dd>${t.mtcn}</dd><dt>External key</dt><dd>${t.external}</dd><dt>Attempt</dt><dd>${t.attempt}</dd><dt>Galactic ID</dt><dd>${t.galactic}</dd><dt>Report group</dt><dd>${t.rg}</dd>`;
 let failed=t.status==='Failed',excluded=t.excluded==='Yes';$('#txn-timeline').innerHTML=`<div class=event><b>Selection</b><br><small>${t.time} · SUCCESS</small></div><div class=event><b>Transaction join</b><br><small>SUCCESS</small></div><div class="event ${failed?'fail':''}"><b>Transformation</b><br><small>${failed?'FAILED · '+t.reason:'SUCCESS'}</small></div><div class="event ${failed?'fail':excluded?'wait':''}"><b>Reporting</b><br><small>${failed?'NOT COMPLETED':excluded?'NOT REQUIRED · '+t.exclusionReason:'COMPLETED'}</small></div>`;
 $('#evidence-rows').innerHTML=`<tr><td>${t.rule}</td><td>${t.reported}</td><td>${t.excluded}</td><td>${t.exclusionReason}</td><td>${t.batch}</td></tr>`;
 $('#next-actions').innerHTML=(failed?['Validate the source value against the rule schema.','Correct or enrich the failed field in the authorized source.','Reprocess the transaction and confirm a higher batch seq_no.','Verify that reporting evidence is created after successful transformation.']:excluded?['Confirm the exclusion strategy is approved for this report group.','Validate the prior reported batch and timestamp.','Close as a legitimate exclusion if evidence is complete.']:['Confirm reported batch and reporting timestamp.','No remediation is required unless reconciliation remains non-zero.']).map(x=>`<li>${x}</li>`).join('');
}

document.addEventListener('DOMContentLoaded',()=>{renderOverview();renderQueue();renderReportGroup();renderBatch();renderTransaction();bindGlobal()});
