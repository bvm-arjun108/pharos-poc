window.queryCatalog={
 Q001:{title:'Batch and report-group volume',question:'What ran during the selected period?',source:'report_transformation_reconciliation',sql:`WITH latest AS (
  SELECT r.*,
         ROW_NUMBER() OVER (
           PARTITION BY rpt_grp_id, batch_id
           ORDER BY seq_no DESC
         ) AS rn
  FROM pharos.report_transformation_reconciliation r
  WHERE run_timestamp >= :from_ts
    AND run_timestamp <  :to_ts
)
SELECT COUNT(*) AS batches_run,
       COUNT(DISTINCT rpt_grp_id) AS report_groups_run
FROM latest
WHERE rn = 1;`},
 Q002:{title:'Batches requiring attention',question:'Which batch executions currently need operator attention?',source:'report_transformation_reconciliation',sql:`WITH latest AS (
  SELECT r.*,
         ROW_NUMBER() OVER (PARTITION BY rpt_grp_id, batch_id ORDER BY seq_no DESC) AS rn
  FROM pharos.report_transformation_reconciliation r
  WHERE run_timestamp >= :from_ts AND run_timestamp < :to_ts
)
SELECT *
FROM latest
WHERE rn = 1
  AND (
       COALESCE(reportable_difference, 0) <> 0
    OR COALESCE(transformation_failed_count, 0) > 0
    OR COALESCE(missing_attempt_count, 0) > 0
    OR COALESCE(transformation_balance_difference, 0) <> 0
  )
ORDER BY ABS(COALESCE(reportable_difference, 0)) DESC,
         transformation_failed_count DESC;`},
 Q003:{title:'Transformation failures',question:'How many records failed transformation?',source:'report_transformation_reconciliation',sql:`WITH latest AS (
  SELECT r.*,
         ROW_NUMBER() OVER (PARTITION BY rpt_grp_id, batch_id ORDER BY seq_no DESC) AS rn
  FROM pharos.report_transformation_reconciliation r
  WHERE run_timestamp >= :from_ts AND run_timestamp < :to_ts
)
SELECT SUM(transformation_failed_count) AS transformation_failures
FROM latest
WHERE rn = 1;`},
 Q004:{title:'Rule-hit reconciliation coverage',question:'Was rule-hit reporting coverage healthy?',source:'rule_hit_reconciliation',sql:`SELECT
  SUM(distinct_rule_hits_count_iwra) AS expected_rule_hits,
  SUM(distinct_rule_hits_count_pharos) AS matched_rule_hits,
  SUM(missed_rule_hits_count_pharos) AS missed_rule_hits,
  ROUND(
    100.0 * SUM(distinct_rule_hits_count_pharos)
    / NULLIF(SUM(distinct_rule_hits_count_iwra), 0), 2
  ) AS match_rate
FROM pharos.rule_hit_reconciliation
WHERE run_date BETWEEN :from_date AND :to_date;`},
 Q005:{title:'Report-group health work queue',question:'Which report groups are creating the greatest operational or compliance risk?',source:'Both reconciliation controls',sql:`WITH batch_health AS (
  SELECT rpt_grp_id,
         COUNT(*) AS batches,
         COUNT(*) FILTER (WHERE COALESCE(reportable_difference,0) <> 0
                            OR COALESCE(transformation_failed_count,0) > 0
                            OR COALESCE(missing_attempt_count,0) > 0) AS issue_batches,
         SUM(transformation_failed_count) AS transformation_failures
  FROM (
    SELECT r.*,
           ROW_NUMBER() OVER (PARTITION BY rpt_grp_id,batch_id ORDER BY seq_no DESC) rn
    FROM pharos.report_transformation_reconciliation r
    WHERE run_timestamp >= :from_ts AND run_timestamp < :to_ts
  ) x WHERE rn = 1
  GROUP BY rpt_grp_id
), coverage AS (
  SELECT rpt_grp_id,
         SUM(distinct_rule_hits_count_iwra) AS expected,
         SUM(distinct_rule_hits_count_pharos) AS matched,
         SUM(missed_rule_hits_count_pharos) AS missed
  FROM pharos.rule_hit_reconciliation
  WHERE run_date BETWEEN :from_date AND :to_date
  GROUP BY rpt_grp_id
)
SELECT COALESCE(b.rpt_grp_id,c.rpt_grp_id) AS rpt_grp_id,
       b.batches,b.issue_batches,b.transformation_failures,
       c.expected,c.matched,c.missed
FROM batch_health b
FULL JOIN coverage c USING (rpt_grp_id)
ORDER BY COALESCE(c.missed,0) DESC,
         COALESCE(b.issue_batches,0) DESC;`},
 Q006:{title:'Priority batch queue',question:'Which exact execution should Operations investigate first?',source:'report_transformation_reconciliation',sql:`SELECT *
FROM (
  SELECT r.*,
         ROW_NUMBER() OVER (PARTITION BY rpt_grp_id,batch_id ORDER BY seq_no DESC) rn
  FROM pharos.report_transformation_reconciliation r
  WHERE run_timestamp >= :from_ts AND run_timestamp < :to_ts
) x
WHERE rn = 1
ORDER BY (COALESCE(reportable_difference,0) <> 0) DESC,
         transformation_failed_count DESC,
         run_timestamp DESC;`},
 Q007:{title:'Selected report-group coverage',question:'Did this report group reconcile its expected rule hits?',source:'rule_hit_reconciliation',sql:`SELECT
  SUM(distinct_rule_hits_count_iwra) AS expected,
  SUM(distinct_rule_hits_count_pharos) AS matched,
  SUM(missed_rule_hits_count_pharos) AS missed
FROM pharos.rule_hit_reconciliation
WHERE rpt_grp_id = :rpt_grp_id
  AND run_date BETWEEN :from_date AND :to_date;`},
 Q008:{title:'Report-group attention summary',question:'What types and volumes of issues affect this report group?',source:'report_transformation_reconciliation',sql:`WITH latest AS (
  SELECT r.*,
         ROW_NUMBER() OVER (PARTITION BY rpt_grp_id,batch_id ORDER BY seq_no DESC) rn
  FROM pharos.report_transformation_reconciliation r
  WHERE rpt_grp_id = :rpt_grp_id
    AND run_timestamp >= :from_ts AND run_timestamp < :to_ts
)
SELECT
  COUNT(*) FILTER (WHERE COALESCE(reportable_difference,0) <> 0
                     OR COALESCE(transformation_failed_count,0) > 0) AS issue_batches,
  SUM(transformation_failed_count) AS failures,
  COUNT(*) FILTER (WHERE COALESCE(reportable_difference,0) <> 0) AS reconciliation_exceptions
FROM latest
WHERE rn = 1;`},
 Q009:{title:'Report-group batch executions',question:'Which batches caused this report group’s current health state?',source:'report_transformation_reconciliation',sql:`SELECT *
FROM (
  SELECT r.*,
         ROW_NUMBER() OVER (PARTITION BY rpt_grp_id,batch_id ORDER BY seq_no DESC) rn
  FROM pharos.report_transformation_reconciliation r
  WHERE rpt_grp_id = :rpt_grp_id
    AND run_timestamp >= :from_ts AND run_timestamp < :to_ts
) x
WHERE rn = 1
ORDER BY run_timestamp DESC;`},
 Q010:{title:'Batch reportability control',question:'Did expected and actual reportable transactions balance for this batch?',source:'report_transformation_reconciliation',sql:`SELECT expected_reportable_count,
       actual_reportable_count,
       reportable_difference,
       seq_no,
       run_timestamp
FROM pharos.report_transformation_reconciliation
WHERE rpt_grp_id = :rpt_grp_id
  AND batch_id = :batch_id
ORDER BY seq_no DESC
LIMIT 1;`},
 Q011:{title:'Batch activity composition',question:'What populations made up the activity selected for this batch?',source:'report_transformation_reconciliation',sql:`SELECT activity_selected_count,
       lookback_transaction_count,
       lookback_actual_count,
       lookback_future_reporting_count,
       reporting_period_transaction_count,
       reporting_period_actual_count,
       reporting_period_future_reporting_count,
       simulated_transaction_count
FROM pharos.report_transformation_reconciliation
WHERE rpt_grp_id = :rpt_grp_id AND batch_id = :batch_id
ORDER BY seq_no DESC
LIMIT 1;`},
 Q012:{title:'Batch transformation control',question:'Did eligible activity reconcile to transformed, failed, duplicate, and residual counts?',source:'report_transformation_reconciliation',sql:`SELECT transformation_eligible_count,
       transformation_success_count,
       transformation_failed_count,
       duplicate_transformation_count,
       transformation_balance_difference
FROM pharos.report_transformation_reconciliation
WHERE rpt_grp_id = :rpt_grp_id AND batch_id = :batch_id
ORDER BY seq_no DESC
LIMIT 1;`},
 Q013:{title:'Batch operational indicators',question:'Which exception indicators may explain this batch’s control difference?',source:'report_transformation_reconciliation',sql:`SELECT missing_attempt_count,
       excluded_transaction_count,
       already_reported_count,
       activity_missing_count,
       soft_dedup_dropped_count,
       transformation_failed_count
FROM pharos.report_transformation_reconciliation
WHERE rpt_grp_id = :rpt_grp_id AND batch_id = :batch_id
ORDER BY seq_no DESC
LIMIT 1;`},
 Q014:{title:'Batch record journey',question:'Which records stopped, at what processing stage, and for what reason?',source:'record_transformation_journey',sql:`SELECT *
FROM pharos.record_transformation_journey
WHERE rpt_grp_id = :rpt_grp_id
  AND batch_id = :batch_id
ORDER BY mtcn, created_timestamp;`},
 Q015:{title:'Linked rule-hit evidence',question:'Which rule-hit dispositions can be linked to this batch?',source:'rule_hit',sql:`SELECT *
FROM pharos.rule_hit
WHERE rpt_grp_id = :rpt_grp_id
  AND efile_batch_id = :batch_id
ORDER BY mtcn, rule_id;`},
 Q016:{title:'Exclusion audit evidence',question:'Why was a transaction legitimately excluded from reporting?',source:'rule_hit_exclusion_audit',sql:`SELECT *
FROM pharos.rule_hit_exclusion_audit
WHERE rpt_grp_id = :rpt_grp_id
  AND processing_batch_id = :batch_id
ORDER BY created_timestamp DESC;`},
 Q017:{title:'Transaction root-cause assessment',question:'What is the most likely root cause for this transaction’s outcome?',source:'record_transformation_journey',sql:`SELECT *
FROM pharos.record_transformation_journey
WHERE rpt_grp_id = :rpt_grp_id
  AND mtcn = :mtcn
ORDER BY created_timestamp;`},
 Q018:{title:'Transaction identifiers',question:'Which identifiers connect this transaction across processing and reporting evidence?',source:'rule_hit',sql:`SELECT rpt_grp_id, rule_id, attempt_id, mtcn,
       external_txn_key, galactic_id, efile_batch_id,
       reported_batch_id, transaction_date
FROM pharos.rule_hit
WHERE rpt_grp_id = :rpt_grp_id
  AND mtcn = :mtcn
ORDER BY rule_id;`},
 Q019:{title:'Transaction processing timeline',question:'What stages did this transaction reach, and where did processing stop?',source:'record_transformation_journey',sql:`SELECT mtcn, batch_id, status, skip_reason, comments, created_timestamp
FROM pharos.record_transformation_journey
WHERE rpt_grp_id = :rpt_grp_id
  AND mtcn = :mtcn
ORDER BY created_timestamp;`},
 Q020:{title:'Rule-hit reporting disposition',question:'Was this rule hit reported, not reported, or excluded?',source:'rule_hit',sql:`SELECT rule_id, mtcn, is_reported, exclusion_reason_id,
       reporting_timestamp, efile_batch_id, reported_batch_id
FROM pharos.rule_hit
WHERE rpt_grp_id = :rpt_grp_id
  AND mtcn = :mtcn
ORDER BY rule_id;`},
 Q021:{title:'Aging and ownership queue',question:'Who owns each open issue, how old is it, and what should be prioritized?',source:'Derived case-management layer',sql:`-- Requires a dashboard-owned operations_case table.
SELECT c.case_id, c.rpt_grp_id, c.batch_id,
       c.severity, c.owner, c.status,
       c.opened_timestamp,
       CURRENT_TIMESTAMP - c.opened_timestamp AS age,
       c.sla_due_timestamp
FROM dashboard.operations_case c
WHERE c.status NOT IN ('CLOSED','RESOLVED')
ORDER BY c.severity, c.sla_due_timestamp;`},
 Q022:{title:'Recommended action classification',question:'What should the operator do next for this transaction?',source:'Journey plus rule-hit evidence',sql:`SELECT j.rpt_grp_id, j.batch_id, j.mtcn,
       j.status, j.skip_reason, j.comments,
       CASE
         WHEN LOWER(COALESCE(j.status,'')) = 'failed'
           THEN 'VALIDATE_REPAIR_REPROCESS'
         WHEN rh.exclusion_reason_id IS NOT NULL
           THEN 'VALIDATE_EXCLUSION_EVIDENCE'
         WHEN rh.is_reported IS TRUE
           THEN 'VERIFY_AND_CLOSE'
         ELSE 'INVESTIGATE_DISPOSITION'
       END AS recommended_action
FROM pharos.record_transformation_journey j
LEFT JOIN pharos.rule_hit rh
  ON rh.rpt_grp_id = j.rpt_grp_id
 AND rh.mtcn = j.mtcn
WHERE j.rpt_grp_id = :rpt_grp_id
  AND j.mtcn = :mtcn;`},
 Q023:{title:'Daily operational health trend',question:'Is operational health improving or deteriorating day by day?',source:'report_transformation_reconciliation',sql:`WITH latest AS (
  SELECT r.*,
         ROW_NUMBER() OVER (PARTITION BY rpt_grp_id,batch_id ORDER BY seq_no DESC) rn
  FROM pharos.report_transformation_reconciliation r
  WHERE run_timestamp >= :from_ts AND run_timestamp < :to_ts
)
SELECT DATE_TRUNC('day', run_timestamp) AS run_day,
       COUNT(*) FILTER (WHERE COALESCE(reportable_difference,0) <> 0
                          OR COALESCE(transformation_failed_count,0) > 0
                          OR COALESCE(missing_attempt_count,0) > 0) AS issue_batches,
       SUM(transformation_failed_count) AS transformation_failures
FROM latest
WHERE rn = 1
GROUP BY DATE_TRUNC('day', run_timestamp)
ORDER BY run_day;`},
 Q024:{title:'Missed-hit exposure ranking',question:'Which report groups contribute the largest missed-hit exposure?',source:'rule_hit_reconciliation',sql:`SELECT rpt_grp_id,
       SUM(distinct_rule_hits_count_iwra) AS expected,
       SUM(distinct_rule_hits_count_pharos) AS matched,
       SUM(missed_rule_hits_count_pharos) AS missed,
       ROUND(100.0 * SUM(distinct_rule_hits_count_pharos)
         / NULLIF(SUM(distinct_rule_hits_count_iwra),0), 2) AS match_rate
FROM pharos.rule_hit_reconciliation
WHERE run_date BETWEEN :from_date AND :to_date
GROUP BY rpt_grp_id
HAVING SUM(missed_rule_hits_count_pharos) > 0
ORDER BY missed DESC;`},

 DQ001:{title:'Locate row-level expected/missed-hit evidence',question:'Which table contains the individual expected rule/transaction records behind missed_rule_hits_count_pharos?',source:'Metadata discovery across candidate tables',open:true,sql:`WITH targets(table_schema, table_name) AS (
  VALUES
    ('pharos','unprocessed_rule_hits'),
    ('pharos','rule_hit_reconciliation_log'),
    ('pharos','rule_hit_reconciliation_analysis'),
    ('pharos','req_reportable_activity')
)
SELECT c.table_schema, c.table_name, c.ordinal_position,
       c.column_name, c.data_type
FROM targets t
LEFT JOIN information_schema.columns c
  ON c.table_schema = t.table_schema
 AND c.table_name = t.table_name
ORDER BY c.table_name, c.ordinal_position;`},
 DQ002:{title:'Confirm report-group dimension and jurisdiction',question:'What is the authoritative source for report-group name, jurisdiction, country, and owner?',source:'Metadata discovery',open:true,sql:`SELECT table_schema, table_name,
       STRING_AGG(column_name, ', ' ORDER BY ordinal_position) AS matching_columns
FROM information_schema.columns
WHERE table_schema NOT IN ('pg_catalog','information_schema')
  AND (
       LOWER(column_name) LIKE '%rpt_grp%'
    OR LOWER(column_name) LIKE '%report_group%'
    OR LOWER(column_name) LIKE '%jurisdiction%'
    OR LOWER(column_name) LIKE '%country%'
    OR LOWER(column_name) LIKE '%owner%'
  )
GROUP BY table_schema, table_name
ORDER BY table_schema, table_name;`},
 DQ003:{title:'Validate batch-link coverage',question:'For which report groups and batches do the e-file, reported-batch, and exclusion-processing links work reliably?',source:'Three-table lineage coverage',open:true,sql:`WITH batches AS (
  SELECT DISTINCT rpt_grp_id, batch_id
  FROM pharos.report_transformation_reconciliation
  WHERE run_timestamp >= :from_ts AND run_timestamp < :to_ts
)
SELECT b.rpt_grp_id, b.batch_id,
       COUNT(DISTINCT rh.mtcn) AS linked_rule_hit_transactions,
       COUNT(DISTINCT ea.mtcn) AS linked_exclusion_transactions
FROM batches b
LEFT JOIN pharos.rule_hit rh
  ON rh.rpt_grp_id = b.rpt_grp_id
 AND rh.efile_batch_id = b.batch_id
LEFT JOIN pharos.rule_hit_exclusion_audit ea
  ON ea.rpt_grp_id = b.rpt_grp_id
 AND ea.processing_batch_id = b.batch_id
GROUP BY b.rpt_grp_id, b.batch_id
ORDER BY b.rpt_grp_id, b.batch_id;`},
 DQ004:{title:'Confirm time and period semantics',question:'Which timestamp defines run date, business date, reporting period, freshness, and SLA aging—and in which timezone?',source:'Five-table timestamp metadata',open:true,sql:`SELECT table_schema, table_name, ordinal_position,
       column_name, data_type
FROM information_schema.columns
WHERE table_schema = 'pharos'
  AND table_name IN (
    'report_transformation_reconciliation',
    'rule_hit_reconciliation',
    'record_transformation_journey',
    'rule_hit',
    'rule_hit_exclusion_audit'
  )
  AND (
       LOWER(column_name) LIKE '%date%'
    OR LOWER(column_name) LIKE '%time%'
    OR LOWER(column_name) LIKE '%period%'
  )
ORDER BY table_name, ordinal_position;`},
 DQ005:{title:'Profile operational status and reason domains',question:'What are the complete, authoritative meanings of status, skip_reason, exclusion reason, and NULL reporting states?',source:'Journey and rule-hit domain profiling',open:true,sql:`SELECT 'journey_status' AS domain,
       COALESCE(status::text,'<NULL>') AS value,
       COUNT(*) AS records
FROM pharos.record_transformation_journey
WHERE created_timestamp >= :from_ts AND created_timestamp < :to_ts
GROUP BY COALESCE(status::text,'<NULL>')
UNION ALL
SELECT 'journey_skip_reason', COALESCE(skip_reason::text,'<NULL>'), COUNT(*)
FROM pharos.record_transformation_journey
WHERE created_timestamp >= :from_ts AND created_timestamp < :to_ts
GROUP BY COALESCE(skip_reason::text,'<NULL>')
UNION ALL
SELECT 'rule_hit_is_reported', COALESCE(is_reported::text,'<NULL>'), COUNT(*)
FROM pharos.rule_hit
WHERE transaction_date BETWEEN :from_date AND :to_date
GROUP BY COALESCE(is_reported::text,'<NULL>')
ORDER BY domain, records DESC;`},
 DQ006:{title:'Find or confirm the case-management source',question:'Where will issue owner, assignment state, notes, SLA, escalation, and resolution evidence be stored?',source:'Metadata discovery for operational case objects',open:true,sql:`SELECT table_schema, table_name,
       STRING_AGG(column_name, ', ' ORDER BY ordinal_position) AS candidate_columns
FROM information_schema.columns
WHERE table_schema NOT IN ('pg_catalog','information_schema')
  AND (
       LOWER(table_name) LIKE '%case%'
    OR LOWER(table_name) LIKE '%incident%'
    OR LOWER(table_name) LIKE '%assignment%'
    OR LOWER(table_name) LIKE '%exception%'
    OR LOWER(column_name) LIKE '%owner%'
    OR LOWER(column_name) LIKE '%assignee%'
    OR LOWER(column_name) LIKE '%sla%'
    OR LOWER(column_name) LIKE '%resolution%'
  )
GROUP BY table_schema, table_name
ORDER BY table_schema, table_name;`}
};

function renderQueryDetail(){
 if(document.body.dataset.page!=='query-detail')return;
 const id=(new URLSearchParams(location.search).get('id')||'Q001').toUpperCase();
 const item=window.queryCatalog[id]||window.queryCatalog.Q001;
 document.querySelectorAll('[data-query-id]').forEach(x=>x.textContent=id);
 document.querySelector('[data-query-title]').textContent=item.title;
 document.querySelector('[data-query-question]').textContent=item.question;
 document.querySelector('[data-query-source]').textContent=item.source;
 document.querySelector('[data-query-sql]').textContent=item.sql;
 document.querySelector('[data-query-status]').innerHTML=item.open?'<span class="badge warning">Open discovery question</span>':'<span class="badge healthy">Dashboard query</span>';
 document.title=`${id} | ${item.title}`;
 document.querySelector('[data-copy-query]').onclick=()=>copyQuery(item.sql);
 document.querySelector('[data-download-query]').onclick=()=>downloadQuery(id,item.sql);
}
async function copyQuery(sql){
 try{await navigator.clipboard.writeText(sql);showQueryToast('Query copied')}catch{
  const t=document.createElement('textarea');t.value=sql;document.body.append(t);t.select();document.execCommand('copy');t.remove();showQueryToast('Query copied')
 }
}
function downloadQuery(id,sql){const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([sql+'\n'],{type:'text/sql'}));a.download=`${id.toLowerCase()}.sql`;a.click();URL.revokeObjectURL(a.href)}
function showQueryToast(text){const t=document.createElement('div');t.className='toast';t.textContent=text;document.body.append(t);setTimeout(()=>t.remove(),1600)}
document.addEventListener('DOMContentLoaded',renderQueryDetail);
