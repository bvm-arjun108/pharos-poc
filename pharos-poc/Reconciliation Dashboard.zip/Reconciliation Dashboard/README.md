# Phase 1 Compliance Operations Dashboard

Open `index.html` directly in a browser. No server, build step, package installation, or network connection is required.

## Investigation flow

1. Overview KPI → KPI-specific work queue
2. Work queue → report group or batch
3. Report group → latest batch execution
4. Batch Control Room → record journey, rule hits, or exclusions
5. Transaction → root cause, evidence, and recommended next action

## Pages

- `index.html` — operating overview and prioritization
- `work-queue.html` — parameter-driven drilldown for every KPI
- `report-group.html` — coverage and batch health
- `batch-control-room.html` — reportability, activity, transformation, and exception controls
- `transaction.html` — root-cause investigation and evidence
- `queries.html` — readable metric catalog
- `query-detail.html` — parameter-driven SQL viewer with copy/download actions
- `queries.sql` — PostgreSQL query templates

## Data model

The dashboard is based on five validated logical tables:

- `report_transformation_reconciliation`
- `rule_hit_reconciliation`
- `record_transformation_journey`
- `rule_hit`
- `rule_hit_exclusion_audit`

All displayed records are mock data. Portfolio totals cover 86 report groups; visible report-group, batch, and chart rankings are explicitly labeled demonstration samples. Query IDs are visible beside each KPI, control, chart, table, and evidence section.

The overview contains two decision-oriented visuals:

- daily issue-batch and transformation-failure trend
- missed-hit exposure ranking for the demonstration sample

The query catalog contains `Q001–Q024` dashboard queries and `DQ001–DQ006` discovery queries for unanswered production-data questions. Every reference opens the exact SQL template with copy and download actions.

## Production integration

Replace the in-memory `model` object in `app.js` with API responses that implement the query catalog. Preserve the URL contract (`view`, `id`, `batch`, and `mtcn`) so deep links remain stable. Add authentication, authorization, audit logging, API error states, paging, and a persistent case-management store for owners, status, notes, and SLA aging.
