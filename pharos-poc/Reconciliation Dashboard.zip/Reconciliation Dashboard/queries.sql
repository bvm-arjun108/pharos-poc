/* Phase 1 Compliance Operations Dashboard — PostgreSQL query catalog
   Bind parameters use :name notation. Confirm physical schema/column names in your environment.
   Core five-table model:
     report_transformation_reconciliation (batch controls)
     rule_hit_reconciliation              (aggregate coverage control)
     record_transformation_journey         (record processing evidence)
     rule_hit                              (row-level rule-hit truth)
     rule_hit_exclusion_audit              (exclusion evidence)
*/

-- Q001 — Operations summary: latest version of each batch
WITH latest AS (
 SELECT r.*, ROW_NUMBER() OVER(PARTITION BY rpt_grp_id,batch_id ORDER BY seq_no DESC) rn
 FROM pharos.report_transformation_reconciliation r
 WHERE run_timestamp >= :from_ts AND run_timestamp < :to_ts
) SELECT COUNT(*) batches_run, COUNT(DISTINCT rpt_grp_id) report_groups_run
FROM latest WHERE rn=1;

-- Q002 — Issue-batch count (same latest-state rule)
WITH latest AS (
 SELECT r.*, ROW_NUMBER() OVER(PARTITION BY rpt_grp_id,batch_id ORDER BY seq_no DESC) rn
 FROM pharos.report_transformation_reconciliation r
 WHERE run_timestamp >= :from_ts AND run_timestamp < :to_ts
) SELECT COUNT(*) AS issue_batches FROM latest WHERE rn=1 AND
(COALESCE(reportable_difference,0)<>0 OR COALESCE(transformation_failed_count,0)>0
 OR COALESCE(missing_attempt_count,0)>0 OR COALESCE(transformation_balance_difference,0)<>0);

-- Q003 — Transformation failures
WITH latest AS (
 SELECT r.*,ROW_NUMBER() OVER(PARTITION BY rpt_grp_id,batch_id ORDER BY seq_no DESC) rn
 FROM pharos.report_transformation_reconciliation r WHERE run_timestamp>=:from_ts AND run_timestamp<:to_ts)
SELECT SUM(transformation_failed_count) transformation_failures FROM latest WHERE rn=1;

-- Q004 — Aggregate rule-hit coverage. Validated: expected = matched + missed.
SELECT SUM(distinct_rule_hits_count_iwra) expected_rule_hits,
       SUM(distinct_rule_hits_count_pharos) matched_rule_hits,
       SUM(missed_rule_hits_count_pharos) missed_rule_hits,
       ROUND(100.0*SUM(distinct_rule_hits_count_pharos)/NULLIF(SUM(distinct_rule_hits_count_iwra),0),2) match_rate
FROM pharos.rule_hit_reconciliation WHERE run_date BETWEEN :from_date AND :to_date;

-- Q005 — Report-group health work queue (aggregate the two control layers independently)
WITH b AS (
 SELECT rpt_grp_id,COUNT(*) batches,COUNT(*) FILTER(WHERE COALESCE(reportable_difference,0)<>0
 OR COALESCE(transformation_failed_count,0)>0 OR COALESCE(missing_attempt_count,0)>0) issue_batches,
 SUM(transformation_failed_count) failures
 FROM (SELECT r.*,ROW_NUMBER() OVER(PARTITION BY rpt_grp_id,batch_id ORDER BY seq_no DESC) rn
 FROM pharos.report_transformation_reconciliation r WHERE run_timestamp>=:from_ts AND run_timestamp<:to_ts) x
 WHERE rn=1 GROUP BY rpt_grp_id), h AS (
 SELECT rpt_grp_id,SUM(distinct_rule_hits_count_iwra) expected,SUM(distinct_rule_hits_count_pharos) matched,
 SUM(missed_rule_hits_count_pharos) missed FROM pharos.rule_hit_reconciliation
 WHERE run_date BETWEEN :from_date AND :to_date GROUP BY rpt_grp_id)
SELECT COALESCE(b.rpt_grp_id,h.rpt_grp_id) rpt_grp_id,b.*,h.* FROM b FULL JOIN h USING(rpt_grp_id)
ORDER BY COALESCE(h.missed,0) DESC,COALESCE(b.issue_batches,0) DESC;

-- Q006 — Priority batches / Q009 — report-group batch list
SELECT * FROM (SELECT r.*,ROW_NUMBER() OVER(PARTITION BY rpt_grp_id,batch_id ORDER BY seq_no DESC) rn
FROM pharos.report_transformation_reconciliation r WHERE run_timestamp>=:from_ts AND run_timestamp<:to_ts) x
WHERE rn=1 AND (:rpt_grp_id IS NULL OR rpt_grp_id=:rpt_grp_id)
ORDER BY (COALESCE(reportable_difference,0)<>0) DESC,transformation_failed_count DESC,run_timestamp DESC;

-- Q007 — Selected report-group reconciliation coverage
SELECT SUM(distinct_rule_hits_count_iwra) expected,SUM(distinct_rule_hits_count_pharos) matched,
SUM(missed_rule_hits_count_pharos) missed FROM pharos.rule_hit_reconciliation
WHERE rpt_grp_id=:rpt_grp_id AND run_date BETWEEN :from_date AND :to_date;

-- Q008 — Selected report-group attention summary
SELECT COUNT(*) FILTER(WHERE COALESCE(reportable_difference,0)<>0 OR COALESCE(transformation_failed_count,0)>0) issue_batches,
SUM(transformation_failed_count) failures,COUNT(*) FILTER(WHERE COALESCE(reportable_difference,0)<>0) recon_exceptions
FROM (SELECT r.*,ROW_NUMBER() OVER(PARTITION BY rpt_grp_id,batch_id ORDER BY seq_no DESC) rn
FROM pharos.report_transformation_reconciliation r WHERE rpt_grp_id=:rpt_grp_id
AND run_timestamp>=:from_ts AND run_timestamp<:to_ts) x WHERE rn=1;

-- Q010/Q011/Q012/Q013 — Latest batch control row; UI maps named control columns into four blocks
SELECT * FROM pharos.report_transformation_reconciliation WHERE rpt_grp_id=:rpt_grp_id AND batch_id=:batch_id
ORDER BY seq_no DESC LIMIT 1;

-- Q014 — Batch record journey
SELECT * FROM pharos.record_transformation_journey
WHERE rpt_grp_id=:rpt_grp_id AND batch_id=:batch_id ORDER BY mtcn,created_timestamp;

-- Q015 — Rule hits linked to the transformation batch (only expose tab when rows exist)
SELECT * FROM pharos.rule_hit WHERE rpt_grp_id=:rpt_grp_id AND efile_batch_id=:batch_id ORDER BY mtcn,rule_id;

-- Q016 — Exclusions linked to processing batch (only expose tab when rows exist)
SELECT * FROM pharos.rule_hit_exclusion_audit
WHERE rpt_grp_id=:rpt_grp_id AND processing_batch_id=:batch_id ORDER BY created_timestamp DESC;

-- Q017/Q019 — Transaction root cause and processing journey
SELECT * FROM pharos.record_transformation_journey
WHERE rpt_grp_id=:rpt_grp_id AND mtcn=:mtcn ORDER BY created_timestamp;

-- Q018/Q020 — Transaction identifiers and rule-hit evidence
SELECT rpt_grp_id,rule_id,attempt_id,mtcn,external_txn_key,galactic_id,is_reported,
exclusion_reason_id,reporting_timestamp,efile_batch_id,reported_batch_id,transaction_date
FROM pharos.rule_hit WHERE rpt_grp_id=:rpt_grp_id AND mtcn=:mtcn ORDER BY rule_id;

-- Q021 — Derived aging/ownership queue.
-- Production note: join this result to an operations_case table owned by the dashboard service.
WITH latest AS (
 SELECT r.*, ROW_NUMBER() OVER(PARTITION BY rpt_grp_id,batch_id ORDER BY seq_no DESC) rn
 FROM pharos.report_transformation_reconciliation r
 WHERE run_timestamp>=:from_ts AND run_timestamp<:to_ts
)
SELECT rpt_grp_id,batch_id,run_timestamp,
 CASE
  WHEN COALESCE(reportable_difference,0)<>0 OR COALESCE(transformation_balance_difference,0)<>0 THEN 'CRITICAL'
  WHEN COALESCE(transformation_failed_count,0)>0 OR COALESCE(missing_attempt_count,0)>0 THEN 'WARNING'
  ELSE 'HEALTHY'
 END AS derived_health
FROM latest WHERE rn=1
ORDER BY derived_health,run_timestamp;

-- Q022 — Evidence-based action classification. This derives a suggestion, not workflow state.
SELECT j.rpt_grp_id,j.batch_id,j.mtcn,j.status,j.skip_reason,j.comments,
 CASE
  WHEN LOWER(COALESCE(j.status,''))='failed' THEN 'VALIDATE_REPAIR_REPROCESS'
  WHEN rh.exclusion_reason_id IS NOT NULL THEN 'VALIDATE_EXCLUSION_EVIDENCE'
  WHEN rh.is_reported IS TRUE THEN 'VERIFY_AND_CLOSE'
  ELSE 'INVESTIGATE_DISPOSITION'
 END AS recommended_action
FROM pharos.record_transformation_journey j
LEFT JOIN pharos.rule_hit rh
 ON rh.rpt_grp_id=j.rpt_grp_id AND rh.mtcn=j.mtcn
WHERE j.rpt_grp_id=:rpt_grp_id AND j.mtcn=:mtcn;

-- Q023 — Daily operational health trend
WITH latest AS (
 SELECT r.*,ROW_NUMBER() OVER(PARTITION BY rpt_grp_id,batch_id ORDER BY seq_no DESC) rn
 FROM pharos.report_transformation_reconciliation r
 WHERE run_timestamp>=:from_ts AND run_timestamp<:to_ts
)
SELECT DATE_TRUNC('day',run_timestamp) run_day,
 COUNT(*) FILTER(WHERE COALESCE(reportable_difference,0)<>0
 OR COALESCE(transformation_failed_count,0)>0
 OR COALESCE(missing_attempt_count,0)>0) issue_batches,
 SUM(transformation_failed_count) transformation_failures
FROM latest WHERE rn=1
GROUP BY DATE_TRUNC('day',run_timestamp)
ORDER BY run_day;

-- Q024 — Missed-hit exposure ranking
SELECT rpt_grp_id,
 SUM(distinct_rule_hits_count_iwra) expected,
 SUM(distinct_rule_hits_count_pharos) matched,
 SUM(missed_rule_hits_count_pharos) missed,
 ROUND(100.0*SUM(distinct_rule_hits_count_pharos)
 / NULLIF(SUM(distinct_rule_hits_count_iwra),0),2) match_rate
FROM pharos.rule_hit_reconciliation
WHERE run_date BETWEEN :from_date AND :to_date
GROUP BY rpt_grp_id
HAVING SUM(missed_rule_hits_count_pharos)>0
ORDER BY missed DESC;

-- DQ001 — Which table contains row-level expected/missed-hit evidence?
WITH targets(table_schema,table_name) AS (VALUES
 ('pharos','unprocessed_rule_hits'),
 ('pharos','rule_hit_reconciliation_log'),
 ('pharos','rule_hit_reconciliation_analysis'),
 ('pharos','req_reportable_activity')
)
SELECT c.table_schema,c.table_name,c.ordinal_position,c.column_name,c.data_type
FROM targets t LEFT JOIN information_schema.columns c
 ON c.table_schema=t.table_schema AND c.table_name=t.table_name
ORDER BY c.table_name,c.ordinal_position;

-- DQ002 — What is the authoritative report-group/jurisdiction dimension?
SELECT table_schema,table_name,
 STRING_AGG(column_name,', ' ORDER BY ordinal_position) matching_columns
FROM information_schema.columns
WHERE table_schema NOT IN ('pg_catalog','information_schema') AND (
 LOWER(column_name) LIKE '%rpt_grp%' OR LOWER(column_name) LIKE '%report_group%'
 OR LOWER(column_name) LIKE '%jurisdiction%' OR LOWER(column_name) LIKE '%country%'
 OR LOWER(column_name) LIKE '%owner%')
GROUP BY table_schema,table_name ORDER BY table_schema,table_name;

-- DQ003 — Where do batch lineage links work reliably?
WITH batches AS (
 SELECT DISTINCT rpt_grp_id,batch_id
 FROM pharos.report_transformation_reconciliation
 WHERE run_timestamp>=:from_ts AND run_timestamp<:to_ts
)
SELECT b.rpt_grp_id,b.batch_id,
 COUNT(DISTINCT rh.mtcn) linked_rule_hit_transactions,
 COUNT(DISTINCT ea.mtcn) linked_exclusion_transactions
FROM batches b
LEFT JOIN pharos.rule_hit rh
 ON rh.rpt_grp_id=b.rpt_grp_id AND rh.efile_batch_id=b.batch_id
LEFT JOIN pharos.rule_hit_exclusion_audit ea
 ON ea.rpt_grp_id=b.rpt_grp_id AND ea.processing_batch_id=b.batch_id
GROUP BY b.rpt_grp_id,b.batch_id ORDER BY b.rpt_grp_id,b.batch_id;

-- DQ004 — Which timestamps define period, freshness, and SLA aging?
SELECT table_schema,table_name,ordinal_position,column_name,data_type
FROM information_schema.columns
WHERE table_schema='pharos' AND table_name IN (
 'report_transformation_reconciliation','rule_hit_reconciliation',
 'record_transformation_journey','rule_hit','rule_hit_exclusion_audit')
AND (LOWER(column_name) LIKE '%date%' OR LOWER(column_name) LIKE '%time%'
 OR LOWER(column_name) LIKE '%period%')
ORDER BY table_name,ordinal_position;

-- DQ005 — What are the authoritative operational status/reason domains?
SELECT 'journey_status' domain,COALESCE(status::text,'<NULL>') value,COUNT(*) records
FROM pharos.record_transformation_journey
WHERE created_timestamp>=:from_ts AND created_timestamp<:to_ts
GROUP BY COALESCE(status::text,'<NULL>')
UNION ALL
SELECT 'journey_skip_reason',COALESCE(skip_reason::text,'<NULL>'),COUNT(*)
FROM pharos.record_transformation_journey
WHERE created_timestamp>=:from_ts AND created_timestamp<:to_ts
GROUP BY COALESCE(skip_reason::text,'<NULL>')
UNION ALL
SELECT 'rule_hit_is_reported',COALESCE(is_reported::text,'<NULL>'),COUNT(*)
FROM pharos.rule_hit WHERE transaction_date BETWEEN :from_date AND :to_date
GROUP BY COALESCE(is_reported::text,'<NULL>')
ORDER BY domain,records DESC;

-- DQ006 — Does a case-management/ownership source already exist?
SELECT table_schema,table_name,
 STRING_AGG(column_name,', ' ORDER BY ordinal_position) candidate_columns
FROM information_schema.columns
WHERE table_schema NOT IN ('pg_catalog','information_schema') AND (
 LOWER(table_name) LIKE '%case%' OR LOWER(table_name) LIKE '%incident%'
 OR LOWER(table_name) LIKE '%assignment%' OR LOWER(table_name) LIKE '%exception%'
 OR LOWER(column_name) LIKE '%owner%' OR LOWER(column_name) LIKE '%assignee%'
 OR LOWER(column_name) LIKE '%sla%' OR LOWER(column_name) LIKE '%resolution%')
GROUP BY table_schema,table_name ORDER BY table_schema,table_name;

-- Phase 1 limitation: do not manufacture row-level records from missed_rule_hits_count_pharos.
-- That aggregate may drill only to its reconciliation record until the expected-side detail source is validated.
