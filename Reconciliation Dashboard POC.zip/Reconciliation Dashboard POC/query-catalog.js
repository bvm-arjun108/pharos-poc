window.queryCatalog={
  "Q001": {
    "title": "Batch and report-group volume",
    "question": "What ran during the selected processing period?",
    "source": "report_transformation_reconciliation + report_batch_info",
    "open": false,
    "sql": "WITH latest AS (\n SELECT DISTINCT ON (r.rpt_grp_id,r.batch_id) r.rpt_grp_id,r.batch_id,r.seq_no,b.process_timestamp\n FROM pharos.report_transformation_reconciliation r JOIN pharos.report_batch_info b USING(rpt_grp_id,batch_id,seq_no)\n WHERE b.process_timestamp>=:from_ts AND b.process_timestamp<:to_ts\n ORDER BY r.rpt_grp_id,r.batch_id,r.seq_no DESC,r.modified_timestamp DESC NULLS LAST)\nSELECT COUNT(*) batches_run,COUNT(DISTINCT rpt_grp_id) report_groups_run,\n MIN(process_timestamp) first_process_time,MAX(process_timestamp) last_process_time FROM latest;"
  },
  "Q002": {
    "title": "Batches requiring attention",
    "question": "Which batch executions currently require attention?",
    "source": "report_transformation_reconciliation + report_batch_info",
    "open": false,
    "sql": "WITH latest AS (\n SELECT DISTINCT ON (r.rpt_grp_id,r.batch_id) r.*,b.process_timestamp,b.batch_status,b.compiler_status,b.report_status\n FROM pharos.report_transformation_reconciliation r JOIN pharos.report_batch_info b USING(rpt_grp_id,batch_id,seq_no)\n WHERE b.process_timestamp>=:from_ts AND b.process_timestamp<:to_ts\n ORDER BY r.rpt_grp_id,r.batch_id,r.seq_no DESC,r.modified_timestamp DESC NULLS LAST)\nSELECT *,COALESCE(actual_reportable_txn,0)-COALESCE(expected_reportable_txn,0) reportable_difference,\n COALESCE(activity_transformed,0)+COALESCE(activity_transformation_failed,0)-COALESCE(actual_activity_eligible_for_transformation,0) transformation_difference\nFROM latest WHERE batch_status='Failed' OR report_status='FAILED'\n OR COALESCE(actual_reportable_txn,0)<>COALESCE(expected_reportable_txn,0)\n OR COALESCE(activity_transformed,0)+COALESCE(activity_transformation_failed,0)<>COALESCE(actual_activity_eligible_for_transformation,0)\n OR COALESCE(activity_transformation_failed,0)>0 OR COALESCE(txn_missing_attempt_count,0)>0\nORDER BY process_timestamp DESC;"
  },
  "Q003": {
    "title": "Transformation failures (aggregate authoritative)",
    "question": "How many records failed transformation?",
    "source": "report_transformation_reconciliation",
    "open": false,
    "sql": "WITH latest AS (\n SELECT DISTINCT ON (r.rpt_grp_id,r.batch_id) r.*,b.process_timestamp\n FROM pharos.report_transformation_reconciliation r JOIN pharos.report_batch_info b USING(rpt_grp_id,batch_id,seq_no)\n WHERE b.process_timestamp>=:from_ts AND b.process_timestamp<:to_ts\n ORDER BY r.rpt_grp_id,r.batch_id,r.seq_no DESC,r.modified_timestamp DESC NULLS LAST)\nSELECT SUM(COALESCE(activity_transformation_failed,0)) transformation_failures,\n COUNT(*) FILTER(WHERE COALESCE(activity_transformation_failed,0)>0) affected_batches FROM latest;"
  },
  "Q004": {
    "title": "External coverage validation control (aggregate only; UI surfaces misses)",
    "question": "Is the aggregate external coverage control internally balanced?",
    "source": "rule_hit_reconciliation",
    "open": false,
    "sql": "WITH latest AS (\n SELECT DISTINCT ON (rpt_grp_id,run_date) * FROM pharos.rule_hit_reconciliation\n WHERE run_date>=:from_run_date AND run_date<=:to_run_date\n ORDER BY rpt_grp_id,run_date,seq_no DESC,modified_timestamp DESC NULLS LAST)\nSELECT SUM(COALESCE(distinct_rule_hits_count_iwra,0)) expected_rule_hits,\n SUM(COALESCE(distinct_rule_hits_count_pharos,0)) matched_rule_hits,\n SUM(COALESCE(missed_rule_hits_count_pharos,0)) missed_rule_hits,\n SUM(COALESCE(distinct_rule_hits_count_iwra,0))-SUM(COALESCE(distinct_rule_hits_count_pharos,0))-SUM(COALESCE(missed_rule_hits_count_pharos,0)) control_difference\nFROM latest;"
  },
  "Q005": {
    "title": "Actionable report-group health with config enrichment and separate external totals",
    "question": "Which configured report groups have failed executions or broken controls?",
    "source": "operational sources + report_group_config",
    "open": false,
    "sql": "WITH latest AS (\n SELECT DISTINCT ON (r.rpt_grp_id,r.batch_id) r.*,b.process_timestamp,b.batch_status,b.compiler_status,b.report_status\n FROM pharos.report_transformation_reconciliation r JOIN pharos.report_batch_info b USING(rpt_grp_id,batch_id,seq_no)\n WHERE b.process_timestamp>=:from_ts AND b.process_timestamp<:to_ts\n ORDER BY r.rpt_grp_id,r.batch_id,r.seq_no DESC,r.modified_timestamp DESC NULLS LAST),\noperational AS (\n SELECT rpt_grp_id,MAX(rpt_grp_name) rpt_grp_name,COUNT(*) batches,\n  COUNT(*) FILTER(WHERE batch_status='Failed' OR report_status='FAILED') failed_batches,\n  COUNT(*) FILTER(WHERE COALESCE(actual_reportable_txn,0)<>COALESCE(expected_reportable_txn,0)) reportability_exceptions,\n  SUM(COALESCE(activity_transformation_failed,0)) transformation_failures,\n  SUM(COALESCE(txn_missing_attempt_count,0)) missing_attempts,\n  COUNT(*) FILTER(WHERE report_status='PARTIAL') partial_outputs,\n  SUM(COALESCE(duplicate_transformation,0)) duplicate_quality_signal,\n  SUM(COALESCE(lookback_future_reporting_txn,0)+COALESCE(reporting_period_future_reporting_txn,0)) future_reporting\n FROM latest GROUP BY rpt_grp_id),\nhit_operational AS (\n SELECT l.rpt_grp_id,\n  COUNT(DISTINCT rh.external_txn_key) FILTER(WHERE rh.is_reported IS TRUE) reported_transactions,\n  COUNT(DISTINCT rh.external_txn_key) FILTER(WHERE rh.is_reported IS FALSE) not_reported_transactions\n FROM latest l JOIN pharos.rule_hit rh\n  ON rh.rpt_grp_id=l.rpt_grp_id AND rh.efile_batch_id=l.batch_id\n GROUP BY l.rpt_grp_id),\nexclusion_operational AS (\n SELECT l.rpt_grp_id,COUNT(DISTINCT e.external_txn_key) excluded_transactions\n FROM latest l JOIN pharos.rule_hit_exclusion_audit e\n  ON e.rpt_grp_id=l.rpt_grp_id AND e.processing_batch_id=l.batch_id\n GROUP BY l.rpt_grp_id),\nexternal_latest AS (\n SELECT DISTINCT ON (rpt_grp_id,run_date) * FROM pharos.rule_hit_reconciliation\n WHERE run_date>=:from_run_date AND run_date<=:to_run_date\n ORDER BY rpt_grp_id,run_date,seq_no DESC,modified_timestamp DESC NULLS LAST),\nexternal AS (\n SELECT rpt_grp_id,SUM(distinct_rule_hits_count_iwra) expected_rule_hits,\n  SUM(distinct_rule_hits_count_pharos) matched_rule_hits,SUM(missed_rule_hits_count_pharos) missed_rule_hits\n FROM external_latest GROUP BY rpt_grp_id)\nSELECT o.*,COALESCE(h.reported_transactions,0) reported_transactions,\n COALESCE(h.not_reported_transactions,0) not_reported_transactions,\n COALESCE(x.excluded_transactions,0) excluded_transactions,\n c.country_name,c.rpt_config_active_flag,c.transformer_version_id,c.rpt_selection_version_id,\n c.reconciliation_strategy_metadata,e.expected_rule_hits,e.matched_rule_hits,e.missed_rule_hits\nFROM operational o LEFT JOIN pharos.report_group_config c\n ON c.rpt_grp_id=o.rpt_grp_id AND c.rpt_config_active_flag IS TRUE\nLEFT JOIN hit_operational h USING(rpt_grp_id)\nLEFT JOIN exclusion_operational x USING(rpt_grp_id)\nLEFT JOIN external e USING(rpt_grp_id)\nORDER BY o.failed_batches DESC,o.reportability_exceptions DESC,o.transformation_failures DESC;"
  },
  "Q006": {
    "title": "Priority latest-batch queue with lifecycle statuses",
    "question": "Which execution should Operations investigate first?",
    "source": "report_transformation_reconciliation + report_batch_info",
    "open": false,
    "sql": "WITH latest AS (\n SELECT DISTINCT ON (r.rpt_grp_id,r.batch_id) r.*,b.process_timestamp,b.batch_status,b.compiler_status,b.report_status\n FROM pharos.report_transformation_reconciliation r JOIN pharos.report_batch_info b USING(rpt_grp_id,batch_id,seq_no)\n WHERE b.process_timestamp>=:from_ts AND b.process_timestamp<:to_ts\n ORDER BY r.rpt_grp_id,r.batch_id,r.seq_no DESC,r.modified_timestamp DESC NULLS LAST)\nSELECT rpt_grp_id,rpt_grp_name,batch_id,seq_no,process_timestamp,batch_status,compiler_status,report_status,\n expected_reportable_txn,actual_reportable_txn,txn_missing_attempt_count,activity_transformation_failed,duplicate_transformation\nFROM latest\nORDER BY (batch_status='Failed' OR report_status='FAILED') DESC,\n (COALESCE(actual_reportable_txn,0)<>COALESCE(expected_reportable_txn,0)) DESC,process_timestamp DESC;"
  },
  "Q007": {
    "title": "Selected report-group external coverage (no batch correlation)",
    "question": "Does this report group have an aggregate external coverage gap?",
    "source": "rule_hit_reconciliation",
    "open": false,
    "sql": "WITH latest AS (\n SELECT DISTINCT ON (rpt_grp_id,run_date) * FROM pharos.rule_hit_reconciliation\n WHERE rpt_grp_id=:rpt_grp_id AND run_date>=:from_run_date AND run_date<=:to_run_date\n ORDER BY rpt_grp_id,run_date,seq_no DESC,modified_timestamp DESC NULLS LAST)\nSELECT rpt_grp_id,MAX(rpt_grp_name) rpt_grp_name,SUM(distinct_rule_hits_count_iwra) expected_rule_hits,\n SUM(distinct_rule_hits_count_pharos) matched_rule_hits,SUM(missed_rule_hits_count_pharos) missed_rule_hits\nFROM latest GROUP BY rpt_grp_id;"
  },
  "Q008": {
    "title": "Selected report-group actionable and supporting indicators",
    "question": "Which processing indicators affect this report group?",
    "source": "report_transformation_reconciliation + report_batch_info",
    "open": false,
    "sql": "WITH latest AS (\n SELECT DISTINCT ON (r.rpt_grp_id,r.batch_id) r.*,b.batch_status,b.report_status\n FROM pharos.report_transformation_reconciliation r JOIN pharos.report_batch_info b USING(rpt_grp_id,batch_id,seq_no)\n WHERE r.rpt_grp_id=:rpt_grp_id AND b.process_timestamp>=:from_ts AND b.process_timestamp<:to_ts\n ORDER BY r.rpt_grp_id,r.batch_id,r.seq_no DESC,r.modified_timestamp DESC NULLS LAST),\noperational AS (\n SELECT COUNT(*) batches,\n COUNT(*) FILTER(WHERE batch_status='Failed' OR report_status='FAILED') failed_batches,\n COUNT(*) FILTER(WHERE COALESCE(actual_reportable_txn,0)<>COALESCE(expected_reportable_txn,0)) reportability_exceptions,\n SUM(COALESCE(txn_missing_attempt_count,0)) missing_attempts,\n SUM(COALESCE(activity_transformation_failed,0)) transformation_failures,\n COUNT(*) FILTER(WHERE report_status='PARTIAL') partial_outputs,\n SUM(COALESCE(duplicate_transformation,0)) duplicate_quality_signal,\n SUM(COALESCE(lookback_future_reporting_txn,0)+COALESCE(reporting_period_future_reporting_txn,0)) future_reporting\n FROM latest),\nhit AS (\n SELECT COUNT(DISTINCT rh.external_txn_key) FILTER(WHERE rh.is_reported IS TRUE) reported_transactions,\n  COUNT(DISTINCT rh.external_txn_key) FILTER(WHERE rh.is_reported IS FALSE) not_reported_transactions\n FROM latest l JOIN pharos.rule_hit rh\n  ON rh.rpt_grp_id=l.rpt_grp_id AND rh.efile_batch_id=l.batch_id),\nexcluded AS (\n SELECT COUNT(DISTINCT e.external_txn_key) excluded_transactions\n FROM latest l JOIN pharos.rule_hit_exclusion_audit e\n  ON e.rpt_grp_id=l.rpt_grp_id AND e.processing_batch_id=l.batch_id)\nSELECT o.*,h.reported_transactions,h.not_reported_transactions,e.excluded_transactions\nFROM operational o CROSS JOIN hit h CROSS JOIN excluded e;"
  },
  "Q009": {
    "title": "Selected report-group latest batch executions",
    "question": "Which batches caused this report group’s processing health?",
    "source": "report_transformation_reconciliation + report_batch_info",
    "open": false,
    "sql": "WITH latest AS (\n SELECT DISTINCT ON (r.rpt_grp_id,r.batch_id) r.*,b.process_timestamp,b.batch_status,b.compiler_status,b.report_status\n FROM pharos.report_transformation_reconciliation r JOIN pharos.report_batch_info b USING(rpt_grp_id,batch_id,seq_no)\n WHERE r.rpt_grp_id=:rpt_grp_id AND b.process_timestamp>=:from_ts AND b.process_timestamp<:to_ts\n ORDER BY r.rpt_grp_id,r.batch_id,r.seq_no DESC,r.modified_timestamp DESC NULLS LAST)\nSELECT * FROM latest ORDER BY process_timestamp DESC;"
  },
  "Q010": {
    "title": "Batch reportability control",
    "question": "Did expected and actual reportable transactions balance?",
    "source": "report_transformation_reconciliation",
    "open": false,
    "sql": "SELECT expected_reportable_txn,actual_reportable_txn,\n COALESCE(actual_reportable_txn,0)-COALESCE(expected_reportable_txn,0) difference\nFROM pharos.report_transformation_reconciliation\nWHERE rpt_grp_id=:rpt_grp_id AND batch_id=:batch_id AND seq_no=:seq_no;"
  },
  "Q011": {
    "title": "Batch activity composition and future-reporting aggregates",
    "question": "How was selected activity composed?",
    "source": "report_transformation_reconciliation",
    "open": false,
    "sql": "SELECT activity_selected,lookback_txn,lookback_actual_txn,lookback_future_reporting_txn,\n reporting_period_txn,reporting_period_actual_txn,reporting_period_future_reporting_txn,activity_simulated,\n COALESCE(lookback_actual_txn,0)+COALESCE(lookback_future_reporting_txn,0)-COALESCE(lookback_txn,0) lookback_difference,\n COALESCE(reporting_period_actual_txn,0)+COALESCE(reporting_period_future_reporting_txn,0)-COALESCE(reporting_period_txn,0) reporting_period_difference\nFROM pharos.report_transformation_reconciliation\nWHERE rpt_grp_id=:rpt_grp_id AND batch_id=:batch_id AND seq_no=:seq_no;"
  },
  "Q012": {
    "title": "Primary transformation control; duplicate is separate",
    "question": "Did Eligible = Transformed + Failed, with duplicates separate?",
    "source": "report_transformation_reconciliation",
    "open": false,
    "sql": "SELECT actual_activity_eligible_for_transformation,activity_transformed,activity_transformation_failed,duplicate_transformation,\n COALESCE(activity_transformed,0)+COALESCE(activity_transformation_failed,0)-COALESCE(actual_activity_eligible_for_transformation,0) transformation_difference\nFROM pharos.report_transformation_reconciliation\nWHERE rpt_grp_id=:rpt_grp_id AND batch_id=:batch_id AND seq_no=:seq_no;"
  },
  "Q013": {
    "title": "Batch operational indicators",
    "question": "Which aggregate indicators support batch diagnosis?",
    "source": "report_transformation_reconciliation",
    "open": false,
    "sql": "SELECT txn_missing_attempt_count,already_reported_count,duplicate_transformation,activity_transformation_failed,\n lookback_future_reporting_txn,reporting_period_future_reporting_txn\nFROM pharos.report_transformation_reconciliation\nWHERE rpt_grp_id=:rpt_grp_id AND batch_id=:batch_id AND seq_no=:seq_no;"
  },
  "Q014": {
    "title": "Latest-state journey evidence; may be incomplete relative to aggregates",
    "question": "What latest-state journey evidence exists for the batch?",
    "source": "record_transformation_journey",
    "open": false,
    "sql": "SELECT identifier,mtcn,stage,status,comments,created_timestamp,modified_timestamp\nFROM pharos.record_transformation_journey WHERE rpt_grp_id=:rpt_grp_id AND batch_id=:batch_id\nORDER BY modified_timestamp DESC NULLS LAST,created_timestamp DESC;"
  },
  "Q015": {
    "title": "Conditional Rule Hits tab (validated transformer bridge)",
    "question": "Which rule hits link to the transformer batch?",
    "source": "rule_hit",
    "open": false,
    "sql": "SELECT external_txn_key,rule_id,attempt_id,mtcn,efile_batch_id,is_reported,status,\n reporting_timestamp,created_timestamp,modified_timestamp\nFROM pharos.rule_hit WHERE rpt_grp_id=:rpt_grp_id AND efile_batch_id=:batch_id\nORDER BY modified_timestamp DESC NULLS LAST,created_timestamp DESC;"
  },
  "Q016": {
    "title": "Conditional Exclusions tab (validated transformer bridge)",
    "question": "Which exclusions link to the transformer batch?",
    "source": "rule_hit_exclusion_audit",
    "open": false,
    "sql": "SELECT mtcn,external_txn_key,rule_id,attempt_id,processing_batch_id,reported_batch_id,\n exclusion_reason_id,exclusion_strategy,reporting_timestamp,created_timestamp\nFROM pharos.rule_hit_exclusion_audit WHERE rpt_grp_id=:rpt_grp_id AND processing_batch_id=:batch_id\nORDER BY created_timestamp DESC;"
  },
  "Q017": {
    "title": "Transaction latest-state root-cause evidence",
    "question": "What is the latest evidence-backed transaction state?",
    "source": "record_transformation_journey",
    "open": false,
    "sql": "SELECT identifier,mtcn,batch_id,stage,status,comments,created_timestamp,modified_timestamp\nFROM pharos.record_transformation_journey WHERE rpt_grp_id=:rpt_grp_id AND mtcn=:mtcn\nORDER BY modified_timestamp DESC NULLS LAST,created_timestamp DESC LIMIT 1;"
  },
  "Q018": {
    "title": "Transaction identifiers and transformer batch inclusion",
    "question": "Which identifiers and transformer batch link this transaction?",
    "source": "rule_hit",
    "open": false,
    "sql": "SELECT rpt_grp_id,external_txn_key,rule_id,attempt_id,mtcn,galactic_id,efile_batch_id,is_reported\nFROM pharos.rule_hit WHERE rpt_grp_id=:rpt_grp_id AND mtcn=:mtcn;"
  },
  "Q019": {
    "title": "Latest known processing state (not an event timeline)",
    "question": "What is the transaction’s latest known processing state?",
    "source": "record_transformation_journey",
    "open": false,
    "sql": "SELECT identifier,mtcn,batch_id,stage,status,comments,created_timestamp,modified_timestamp\nFROM pharos.record_transformation_journey WHERE rpt_grp_id=:rpt_grp_id AND mtcn=:mtcn\nORDER BY modified_timestamp DESC NULLS LAST,created_timestamp DESC LIMIT 1;"
  },
  "Q020": {
    "title": "Transformer output versus downstream persisted reporting state",
    "question": "What do transformer inclusion and downstream reporting state show?",
    "source": "rule_hit",
    "open": false,
    "sql": "SELECT rule_id,external_txn_key,mtcn,efile_batch_id,is_reported,status,reporting_timestamp\nFROM pharos.rule_hit WHERE rpt_grp_id=:rpt_grp_id AND mtcn=:mtcn;"
  },
  "Q021": {
    "title": "Latest batch/compiler/report lifecycle status profile",
    "question": "Which lifecycle status combinations occur in the period?",
    "source": "report_batch_info",
    "open": false,
    "sql": "WITH latest AS (\n SELECT DISTINCT ON (rpt_grp_id,batch_id) rpt_grp_id,batch_id,seq_no,process_timestamp,batch_status,compiler_status,report_status\n FROM pharos.report_batch_info WHERE process_timestamp>=:from_ts AND process_timestamp<:to_ts\n ORDER BY rpt_grp_id,batch_id,seq_no DESC,process_timestamp DESC)\nSELECT COALESCE(batch_status,'<NULL>') batch_status,COALESCE(compiler_status,'<NULL>') compiler_status,\n COALESCE(report_status,'<NULL>') report_status,COUNT(*) rows\nFROM latest GROUP BY batch_status,compiler_status,report_status ORDER BY rows DESC;"
  },
  "Q022": {
    "title": "Evidence-based next-action classification (advisory)",
    "question": "What evidence-based next action is suggested?",
    "source": "record_transformation_journey + rule_hit",
    "open": false,
    "sql": "SELECT j.rpt_grp_id,j.batch_id,j.mtcn,j.stage,j.status,j.comments,rh.efile_batch_id,rh.is_reported,\n CASE WHEN j.stage='TRANSFORMATION' AND j.status='FAILURE' THEN 'REPAIR_AND_REPROCESS'\n      WHEN j.stage='TRANSACTION_JOIN' AND j.status='ERROR' THEN 'RESOLVE_MISSING_ATTEMPT'\n      WHEN rh.efile_batch_id IS NOT NULL AND rh.is_reported IS FALSE THEN 'CHECK_DOWNSTREAM_REPORTING'\n      ELSE 'REVIEW_EVIDENCE' END recommended_action\nFROM pharos.record_transformation_journey j\nLEFT JOIN pharos.rule_hit rh ON rh.rpt_grp_id=j.rpt_grp_id AND rh.mtcn=j.mtcn\nWHERE j.rpt_grp_id=:rpt_grp_id AND j.mtcn=:mtcn;"
  },
  "Q023": {
    "title": "Adaptive operational trend: daily through 31 days, weekly beyond 31 days",
    "question": "How are attention batches and failures changing across the complete selected window?",
    "source": "report_transformation_reconciliation + report_batch_info",
    "open": false,
    "sql": "WITH latest AS (\n SELECT DISTINCT ON (r.rpt_grp_id,r.batch_id) r.rpt_grp_id,r.batch_id,r.activity_transformation_failed,\n  b.process_timestamp,b.batch_status,b.report_status\n FROM pharos.report_transformation_reconciliation r JOIN pharos.report_batch_info b USING(rpt_grp_id,batch_id,seq_no)\n WHERE b.process_timestamp>=:from_ts AND b.process_timestamp<:to_ts\n ORDER BY r.rpt_grp_id,r.batch_id,r.seq_no DESC,r.modified_timestamp DESC NULLS LAST),\nbucketed AS (\n SELECT CASE WHEN CAST(:to_ts AS timestamp)-CAST(:from_ts AS timestamp)<=INTERVAL '31 days'\n   THEN DATE_TRUNC('day',process_timestamp) ELSE DATE_TRUNC('week',process_timestamp) END period_bucket,\n  batch_status,report_status,activity_transformation_failed\n FROM latest)\nSELECT period_bucket,COUNT(*) batches,\n COUNT(*) FILTER(WHERE batch_status='Failed' OR report_status='FAILED') failed_batches,\n SUM(COALESCE(activity_transformation_failed,0)) transformation_failures\nFROM bucketed GROUP BY period_bucket ORDER BY period_bucket;"
  },
  "Q024": {
    "title": "Report groups with aggregate misses in the external reconciliation run",
    "question": "Which report groups have an aggregate external coverage gap?",
    "source": "rule_hit_reconciliation",
    "open": false,
    "sql": "WITH latest AS (\n SELECT DISTINCT ON (rpt_grp_id,run_date) * FROM pharos.rule_hit_reconciliation\n WHERE run_date>=:from_run_date AND run_date<=:to_run_date\n ORDER BY rpt_grp_id,run_date,seq_no DESC,modified_timestamp DESC NULLS LAST)\nSELECT rpt_grp_id,MAX(rpt_grp_name) rpt_grp_name,SUM(distinct_rule_hits_count_iwra) expected_rule_hits,\n SUM(distinct_rule_hits_count_pharos) matched_rule_hits,SUM(missed_rule_hits_count_pharos) missed_rule_hits\nFROM latest\nGROUP BY rpt_grp_id HAVING SUM(missed_rule_hits_count_pharos)>0 ORDER BY missed_rule_hits DESC;"
  },
  "Q025": {
    "title": "Selected batch outcome signals from independent evidence populations",
    "question": "What reported, not-reported, excluded, failed, and future signals exist for this batch?",
    "source": "batch controls + rule_hit + rule_hit_exclusion_audit",
    "open": false,
    "sql": "WITH selected_batch AS (\n SELECT r.rpt_grp_id,r.rpt_grp_name,r.batch_id,r.seq_no,b.process_timestamp,\n  r.activity_transformation_failed,r.txn_missing_attempt_count,\n  COALESCE(r.lookback_future_reporting_txn,0)+COALESCE(r.reporting_period_future_reporting_txn,0) future_reporting\n FROM pharos.report_transformation_reconciliation r\n JOIN pharos.report_batch_info b USING(rpt_grp_id,batch_id,seq_no)\n WHERE r.rpt_grp_id=:rpt_grp_id AND r.batch_id=:batch_id AND r.seq_no=:seq_no),\nhit_summary AS (\n SELECT rpt_grp_id,efile_batch_id batch_id,\n  COUNT(DISTINCT external_txn_key) linked_transactions,\n  COUNT(DISTINCT external_txn_key) FILTER(WHERE is_reported IS TRUE) reported_transactions,\n  COUNT(DISTINCT external_txn_key) FILTER(WHERE is_reported IS FALSE) not_reported_transactions\n FROM pharos.rule_hit WHERE rpt_grp_id=:rpt_grp_id AND efile_batch_id=:batch_id\n GROUP BY rpt_grp_id,efile_batch_id),\nexclusion_summary AS (\n SELECT rpt_grp_id,processing_batch_id batch_id,\n  COUNT(DISTINCT external_txn_key) excluded_transactions\n FROM pharos.rule_hit_exclusion_audit\n WHERE rpt_grp_id=:rpt_grp_id AND processing_batch_id=:batch_id\n GROUP BY rpt_grp_id,processing_batch_id)\nSELECT b.*,COALESCE(h.linked_transactions,0) linked_transactions,\n COALESCE(h.reported_transactions,0) reported_transactions,\n COALESCE(h.not_reported_transactions,0) not_reported_transactions,\n COALESCE(e.excluded_transactions,0) excluded_transactions\nFROM selected_batch b LEFT JOIN hit_summary h USING(rpt_grp_id,batch_id)\nLEFT JOIN exclusion_summary e USING(rpt_grp_id,batch_id);"
  },
  "Q026": {
    "title": "Batch transformation-failure reasons with aggregate coverage comparison",
    "question": "Why did available records fail, and how much of the aggregate has reason evidence?",
    "source": "report_transformation_reconciliation + record_transformation_journey",
    "open": false,
    "sql": "WITH authoritative AS (\n SELECT rpt_grp_id,batch_id,seq_no,activity_transformation_failed authoritative_failures\n FROM pharos.report_transformation_reconciliation\n WHERE rpt_grp_id=:rpt_grp_id AND batch_id=:batch_id AND seq_no=:seq_no),\nreason_counts AS (\n SELECT rpt_grp_id,batch_id,COALESCE(comments,'Reason not populated') failure_reason,\n  COUNT(*) evidence_rows\n FROM pharos.record_transformation_journey\n WHERE rpt_grp_id=:rpt_grp_id AND batch_id=:batch_id\n  AND stage='TRANSFORMATION' AND status='FAILURE'\n GROUP BY rpt_grp_id,batch_id,COALESCE(comments,'Reason not populated'))\nSELECT a.rpt_grp_id,a.batch_id,a.seq_no,a.authoritative_failures,\n COALESCE(r.failure_reason,'No journey reason evidence') failure_reason,\n COALESCE(r.evidence_rows,0) evidence_rows,\n SUM(COALESCE(r.evidence_rows,0)) OVER() total_reason_evidence_rows\nFROM authoritative a LEFT JOIN reason_counts r USING(rpt_grp_id,batch_id)\nORDER BY evidence_rows DESC,failure_reason;"
  },
  "Q027": {
    "title": "Rule outcomes linked to a selected transformer batch",
    "question": "Which rules and persisted reporting dispositions are linked to this batch?",
    "source": "rule_hit",
    "open": false,
    "sql": "SELECT rule_id,COUNT(DISTINCT external_txn_key) linked_transactions,\n COUNT(DISTINCT external_txn_key) FILTER(WHERE is_reported IS TRUE) reported_transactions,\n COUNT(DISTINCT external_txn_key) FILTER(WHERE is_reported IS FALSE) not_reported_transactions,\n COUNT(DISTINCT attempt_id) attempts\nFROM pharos.rule_hit\nWHERE rpt_grp_id=:rpt_grp_id AND efile_batch_id=:batch_id\nGROUP BY rule_id ORDER BY not_reported_transactions DESC,linked_transactions DESC;"
  },
  "Q028": {
    "title": "Searchable transaction registry using the latest available evidence",
    "question": "Which latest transaction evidence is available across the Phase 1 sources?",
    "source": "record_transformation_journey + rule_hit + rule_hit_exclusion_audit",
    "open": false,
    "sql": "WITH latest_batch AS (\n SELECT DISTINCT ON (rpt_grp_id,batch_id) rpt_grp_id,batch_id,seq_no,process_timestamp\n FROM pharos.report_batch_info\n WHERE process_timestamp>=:from_ts AND process_timestamp<:to_ts\n ORDER BY rpt_grp_id,batch_id,seq_no DESC,process_timestamp DESC),\nlatest_journey AS (\n SELECT DISTINCT ON (j.rpt_grp_id,j.mtcn) j.rpt_grp_id,j.mtcn,j.batch_id,j.identifier,j.stage,j.status,j.comments,\n  j.created_timestamp,j.modified_timestamp\n FROM pharos.record_transformation_journey j\n JOIN latest_batch b ON b.rpt_grp_id=j.rpt_grp_id AND b.batch_id=j.batch_id\n ORDER BY j.rpt_grp_id,j.mtcn,j.modified_timestamp DESC NULLS LAST,j.created_timestamp DESC),\nhit AS (\n SELECT rh.rpt_grp_id,rh.mtcn,MIN(rh.external_txn_key) external_txn_key,\n  STRING_AGG(DISTINCT rh.rule_id::text,', ' ORDER BY rh.rule_id::text) rule_ids,\n  MIN(rh.attempt_id) attempt_id,MIN(rh.galactic_id) galactic_id,MIN(rh.efile_batch_id) efile_batch_id,\n  BOOL_OR(rh.is_reported IS TRUE) is_reported,MAX(rh.reporting_timestamp) reporting_timestamp\n FROM pharos.rule_hit rh\n JOIN latest_batch b ON b.rpt_grp_id=rh.rpt_grp_id AND b.batch_id=rh.efile_batch_id\n GROUP BY rh.rpt_grp_id,rh.mtcn),\nexcluded AS (\n SELECT e.rpt_grp_id,e.mtcn,BOOL_OR(TRUE) is_excluded,\n  MAX(e.exclusion_reason_id::text) exclusion_reason,MAX(e.exclusion_strategy::text) exclusion_strategy,\n  MAX(e.created_timestamp) exclusion_timestamp\n FROM pharos.rule_hit_exclusion_audit e\n JOIN latest_batch b ON b.rpt_grp_id=e.rpt_grp_id AND b.batch_id=e.processing_batch_id\n GROUP BY e.rpt_grp_id,e.mtcn)\nSELECT COALESCE(j.rpt_grp_id,h.rpt_grp_id) rpt_grp_id,COALESCE(j.mtcn,h.mtcn) mtcn,\n COALESCE(j.batch_id,h.efile_batch_id) batch_id,j.identifier,j.stage,j.status,j.comments,\n h.external_txn_key,h.rule_ids,h.attempt_id,h.galactic_id,h.is_reported,h.reporting_timestamp,\n COALESCE(e.is_excluded,FALSE) is_excluded,e.exclusion_reason,e.exclusion_strategy,e.exclusion_timestamp,\n j.modified_timestamp latest_journey_timestamp\nFROM latest_journey j FULL OUTER JOIN hit h USING(rpt_grp_id,mtcn)\nLEFT JOIN excluded e ON e.rpt_grp_id=COALESCE(j.rpt_grp_id,h.rpt_grp_id)\n AND e.mtcn=COALESCE(j.mtcn,h.mtcn)\nORDER BY COALESCE(j.modified_timestamp,h.reporting_timestamp) DESC NULLS LAST;"
  },
  "Q029": {
    "title": "Normalized audit evidence for one transaction",
    "question": "Which source rows support the audit explanation for this transaction?",
    "source": "journey + rule_hit + exclusion audit",
    "open": false,
    "sql": "SELECT 'record_transformation_journey' evidence_source,stage evidence_type,status evidence_status,\n comments evidence_detail,batch_id evidence_batch,modified_timestamp evidence_timestamp\nFROM pharos.record_transformation_journey\nWHERE rpt_grp_id=:rpt_grp_id AND mtcn=:mtcn\nUNION ALL\nSELECT 'rule_hit','RULE_HIT',CASE WHEN is_reported THEN 'REPORTED' ELSE 'NOT_REPORTED' END,\n CONCAT('rule=',rule_id,', external_txn_key=',external_txn_key),efile_batch_id,modified_timestamp\nFROM pharos.rule_hit WHERE rpt_grp_id=:rpt_grp_id AND mtcn=:mtcn\nUNION ALL\nSELECT 'rule_hit_exclusion_audit','EXCLUSION','EXCLUDED',\n CONCAT('reason=',COALESCE(exclusion_reason_id::text,'Reason not populated'),', strategy=',COALESCE(exclusion_strategy::text,'<NULL>')),\n processing_batch_id,created_timestamp\nFROM pharos.rule_hit_exclusion_audit WHERE rpt_grp_id=:rpt_grp_id AND mtcn=:mtcn\nORDER BY evidence_timestamp DESC NULLS LAST;"
  },
  "Q030": {
    "title": "Transaction future-reporting assessment when timestamp evidence is available",
    "question": "Can linked timestamps classify this transaction as future reportable?",
    "source": "rule_hit + report_batch_info + report_group_config",
    "open": false,
    "sql": "WITH latest_batch AS (\n SELECT DISTINCT ON (rpt_grp_id,batch_id) rpt_grp_id,batch_id,seq_no,\n  txn_lookback_start_timestamp,txn_start_timestamp,txn_end_timestamp\n FROM pharos.report_batch_info\n ORDER BY rpt_grp_id,batch_id,seq_no DESC,process_timestamp DESC)\nSELECT rh.rpt_grp_id,rh.mtcn,rh.external_txn_key,rh.rule_id,rh.efile_batch_id,\n rh.created_timestamp,rh.reporting_timestamp,c.reconciliation_strategy_metadata,\n CASE WHEN rh.reporting_timestamp IS NULL OR b.batch_id IS NULL THEN 'EVIDENCE_UNAVAILABLE'\n      WHEN DATE(rh.created_timestamp)=DATE(rh.reporting_timestamp) THEN 'NOT_FUTURE_REPORTING'\n      WHEN rh.reporting_timestamp>=b.txn_lookback_start_timestamp\n       AND rh.reporting_timestamp<b.txn_start_timestamp THEN 'LOOKBACK_FUTURE_REPORTING'\n      WHEN rh.reporting_timestamp>=b.txn_start_timestamp\n       AND rh.reporting_timestamp<=b.txn_end_timestamp THEN 'REPORTING_PERIOD_FUTURE_REPORTING'\n      ELSE 'NOT_FUTURE_REPORTING' END future_reporting_assessment\nFROM pharos.rule_hit rh\nLEFT JOIN latest_batch b ON b.rpt_grp_id=rh.rpt_grp_id AND b.batch_id=rh.efile_batch_id\nLEFT JOIN pharos.report_group_config c\n ON c.rpt_grp_id=rh.rpt_grp_id AND c.rpt_config_active_flag IS TRUE\nWHERE rh.rpt_grp_id=:rpt_grp_id AND rh.mtcn=:mtcn;"
  },
  "Q031": {
    "title": "Rule explorer summary across linked batches and dispositions",
    "question": "Which rules are associated with not-reported, excluded, or failed records?",
    "source": "rule_hit + journey + exclusion audit",
    "open": false,
    "sql": "WITH latest_batch AS (\n SELECT DISTINCT ON (rpt_grp_id,batch_id) rpt_grp_id,batch_id,seq_no,process_timestamp\n FROM pharos.report_batch_info\n WHERE process_timestamp>=:from_ts AND process_timestamp<:to_ts\n ORDER BY rpt_grp_id,batch_id,seq_no DESC,process_timestamp DESC),\nhit AS (\n SELECT rh.rpt_grp_id,rh.rule_id,COUNT(DISTINCT rh.external_txn_key) linked_transactions,\n  COUNT(DISTINCT rh.external_txn_key) FILTER(WHERE rh.is_reported IS TRUE) reported_transactions,\n  COUNT(DISTINCT rh.external_txn_key) FILTER(WHERE rh.is_reported IS FALSE) not_reported_transactions,\n  COUNT(DISTINCT rh.efile_batch_id) affected_batches\n FROM pharos.rule_hit rh JOIN latest_batch b ON b.rpt_grp_id=rh.rpt_grp_id AND b.batch_id=rh.efile_batch_id\n GROUP BY rh.rpt_grp_id,rh.rule_id),\nexcluded AS (\n SELECT e.rpt_grp_id,e.rule_id,COUNT(DISTINCT e.external_txn_key) excluded_transactions\n FROM pharos.rule_hit_exclusion_audit e\n JOIN latest_batch b ON b.rpt_grp_id=e.rpt_grp_id AND b.batch_id=e.processing_batch_id\n GROUP BY e.rpt_grp_id,e.rule_id),\nfailed AS (\n SELECT rh.rpt_grp_id,rh.rule_id,COUNT(DISTINCT j.mtcn) failed_evidence_rows\n FROM pharos.rule_hit rh JOIN latest_batch b ON b.rpt_grp_id=rh.rpt_grp_id AND b.batch_id=rh.efile_batch_id\n JOIN pharos.record_transformation_journey j ON j.rpt_grp_id=rh.rpt_grp_id AND j.mtcn=rh.mtcn\n WHERE j.stage='TRANSFORMATION' AND j.status='FAILURE' GROUP BY rh.rpt_grp_id,rh.rule_id)\nSELECT h.*,c.rpt_grp_name,c.country_name,COALESCE(e.excluded_transactions,0) excluded_transactions,\n COALESCE(f.failed_evidence_rows,0) failed_evidence_rows\nFROM hit h LEFT JOIN excluded e USING(rpt_grp_id,rule_id)\nLEFT JOIN failed f USING(rpt_grp_id,rule_id)\nLEFT JOIN pharos.report_group_config c\n ON c.rpt_grp_id=h.rpt_grp_id AND c.rpt_config_active_flag IS TRUE\nORDER BY failed_evidence_rows DESC,not_reported_transactions DESC,linked_transactions DESC;"
  },
  "Q032": {
    "title": "Selected rule detail with affected batches and latest transaction evidence",
    "question": "Which batches and transactions are affected by this rule?",
    "source": "rule_hit + report_batch_info + journey",
    "open": false,
    "sql": "WITH latest_batch AS (\n SELECT DISTINCT ON (rpt_grp_id,batch_id) rpt_grp_id,batch_id,seq_no,process_timestamp,batch_status,report_status\n FROM pharos.report_batch_info\n WHERE process_timestamp>=:from_ts AND process_timestamp<:to_ts\n ORDER BY rpt_grp_id,batch_id,seq_no DESC,process_timestamp DESC),\nlatest_journey AS (\n SELECT DISTINCT ON (rpt_grp_id,mtcn) rpt_grp_id,mtcn,stage,status,comments,modified_timestamp\n FROM pharos.record_transformation_journey\n ORDER BY rpt_grp_id,mtcn,modified_timestamp DESC NULLS LAST,created_timestamp DESC)\nSELECT rh.rpt_grp_id,rh.rule_id,rh.mtcn,rh.external_txn_key,rh.attempt_id,rh.galactic_id,\n rh.efile_batch_id,b.process_timestamp,b.batch_status,b.report_status,rh.is_reported,rh.reporting_timestamp,\n j.stage latest_stage,j.status latest_status,j.comments latest_reason,j.modified_timestamp latest_journey_timestamp\nFROM pharos.rule_hit rh\nJOIN latest_batch b ON b.rpt_grp_id=rh.rpt_grp_id AND b.batch_id=rh.efile_batch_id\nLEFT JOIN latest_journey j ON j.rpt_grp_id=rh.rpt_grp_id AND j.mtcn=rh.mtcn\nWHERE rh.rpt_grp_id=:rpt_grp_id AND rh.rule_id=:rule_id\nORDER BY b.process_timestamp DESC,rh.modified_timestamp DESC NULLS LAST;"
  },
  "Q033": {
    "title": "Portfolio outcome summary for the selected operating window",
    "question": "What are the independent outcome totals across the selected operating window?",
    "source": "batch controls + rule_hit + rule_hit_exclusion_audit",
    "open": false,
    "sql": "WITH latest AS (\n SELECT DISTINCT ON (r.rpt_grp_id,r.batch_id) r.rpt_grp_id,r.batch_id,r.seq_no,\n  r.activity_transformation_failed,r.txn_missing_attempt_count,\n  r.lookback_future_reporting_txn,r.reporting_period_future_reporting_txn\n FROM pharos.report_transformation_reconciliation r\n JOIN pharos.report_batch_info b USING(rpt_grp_id,batch_id,seq_no)\n WHERE b.process_timestamp>=:from_ts AND b.process_timestamp<:to_ts\n ORDER BY r.rpt_grp_id,r.batch_id,r.seq_no DESC,r.modified_timestamp DESC NULLS LAST),\nhit AS (\n SELECT COUNT(DISTINCT (rh.rpt_grp_id,rh.external_txn_key)) FILTER(WHERE rh.is_reported IS TRUE) reported_transactions,\n  COUNT(DISTINCT (rh.rpt_grp_id,rh.external_txn_key)) FILTER(WHERE rh.is_reported IS FALSE) not_reported_transactions\n FROM latest l JOIN pharos.rule_hit rh\n  ON rh.rpt_grp_id=l.rpt_grp_id AND rh.efile_batch_id=l.batch_id),\nexcluded AS (\n SELECT COUNT(DISTINCT (e.rpt_grp_id,e.external_txn_key)) excluded_transactions\n FROM latest l JOIN pharos.rule_hit_exclusion_audit e\n  ON e.rpt_grp_id=l.rpt_grp_id AND e.processing_batch_id=l.batch_id),\nbatch_totals AS (\n SELECT COUNT(*) batches,\n  SUM(COALESCE(activity_transformation_failed,0)) transformation_failures,\n  SUM(COALESCE(txn_missing_attempt_count,0)) missing_attempts,\n  SUM(COALESCE(lookback_future_reporting_txn,0)+COALESCE(reporting_period_future_reporting_txn,0)) future_reporting\n FROM latest)\nSELECT b.*,h.reported_transactions,h.not_reported_transactions,e.excluded_transactions\nFROM batch_totals b CROSS JOIN hit h CROSS JOIN excluded e;"
  }
};

function renderQueryDetail(){if(document.body.dataset.page!=='query-detail')return;const id=(new URLSearchParams(location.search).get('id')||'Q001').toUpperCase();const item=window.queryCatalog[id]||window.queryCatalog.Q001;document.querySelectorAll('[data-query-id]').forEach(x=>x.textContent=id);document.querySelector('[data-query-title]').textContent=item.title;document.querySelector('[data-query-question]').textContent=item.question;document.querySelector('[data-query-source]').textContent=item.source;document.querySelector('[data-query-sql]').textContent=item.sql;document.querySelector('[data-query-status]').innerHTML='<span class="badge healthy">Validated Phase 1 query</span>';document.title=id+' | '+item.title;document.querySelector('[data-copy-query]').onclick=()=>copyQuery(item.sql);document.querySelector('[data-download-query]').onclick=()=>downloadQuery(id,item.sql)}
async function copyQuery(sql){try{await navigator.clipboard.writeText(sql);showQueryToast('Query copied')}catch{const t=document.createElement('textarea');t.value=sql;document.body.append(t);t.select();document.execCommand('copy');t.remove();showQueryToast('Query copied')}}
function downloadQuery(id,sql){const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([sql+'\n'],{type:'text/sql'}));a.download=id.toLowerCase()+'.sql';a.click();URL.revokeObjectURL(a.href)}
function showQueryToast(text){const t=document.createElement('div');t.className='toast';t.textContent=text;document.body.append(t);setTimeout(()=>t.remove(),1600)}
document.addEventListener('DOMContentLoaded',renderQueryDetail);