# Phase 1 Compliance Operations Investigation Dashboard

Open `index.html` directly in a browser. The project is an offline production demo: no server, build step, package installation, or network connection is required.

## Product purpose

The dashboard is built to answer an operator’s questions and preserve the evidence needed for a later audit.

### Batch-first investigation

1. Which batches ran in the selected period?
2. How many need attention?
3. Which report group is affected?
4. How many distinct linked transactions were marked reported or excluded?
5. How many failed transformation?
6. Which available reasons explain the failures or exclusions?
7. Which source rows support the conclusion?

### Transaction-first investigation

1. Why was this transaction not reported?
2. Did it fail, get excluded, move to future reporting, or finish transformation but remain pending downstream?
3. Which report group, batch, rule, and attempt does it belong to?
4. Is future-reporting evidence available?
5. What is the latest known processing state?
6. What should the operator do next?
7. What audit explanation can be copied into a case or evidence package?

### Rule-first investigation

1. Which rules are associated with not-reported, excluded, or failed records?
2. Which batches and report groups are affected?
3. What is the leading available reason?
4. Which transactions provide supporting evidence?

All three paths converge on the same batch, rule, transaction, and source-evidence records.

## Pages

- `index.html` — investigation center, period summary, and three entry paths
- `batches.html` — batch explorer answering what ran and what needs attention
- `batch-control-room.html` — batch outcomes, reasons, controls, records, rules, exclusions, and audit explanation
- `transactions.html` — searchable record-evidence registry
- `transaction.html` — direct reporting explanation, root cause, future assessment, evidence provenance, and next action
- `rules.html` — rule-level outcome explorer
- `rule.html` — affected batches, reasons, and transaction evidence for one rule
- `report-group.html` — report-group context and its batch/outcome summary
- `work-queue.html` — focused supporting queues and aggregate external exceptions
- `queries.html` / `query-detail.html` — interactive query catalog
- `queries.sql` — PostgreSQL templates Q001–Q033
- `PHASE1_DATA_CONTRACT.md` — sources, equations, joins, and evidence boundaries
- `SCHEMA_REFERENCE.md` — conversation-derived physical table and column reference
- `AUDIT_EVIDENCE_GUIDE.md` — what the dashboard can and cannot prove
- `VALIDATION.md` — project validation summary

## Data model

The six Phase 1 operational sources are:

- `report_transformation_reconciliation`
- `record_transformation_journey`
- `rule_hit`
- `rule_hit_exclusion_audit`
- `rule_hit_reconciliation`
- `report_batch_info`

`report_group_config` is used only as reference/configuration enrichment.

The project does not depend on `rule_hit_reconciliation_log`, `rule_hit_reconciliation_analysis`, or `unprocessed_rule_hits`. External misses therefore remain aggregate-only.

## Evidence hierarchy

1. `report_transformation_reconciliation` supplies authoritative batch aggregate counts and controls.
2. `report_batch_info` supplies operational process time and batch/compiler/report lifecycle state.
3. `record_transformation_journey` supplies latest-state record evidence when available; it is not complete event history.
4. `rule_hit` supplies transformer-batch inclusion, rule identifiers, and persisted downstream `is_reported` state.
5. `rule_hit_exclusion_audit` supplies exclusion reasons and strategies when linked evidence exists.
6. `rule_hit_reconciliation` supplies a separate aggregate external coverage control.

The batch outcome cards are deliberately independent. Reported, excluded, failed, future-reporting, and missing-attempt populations can have different grains and must not be presented as a forced linear funnel.

## Time-window behavior

The 7-, 30-, and 60-day selector updates operating totals and trends. Q023 applies the same rule as the demo:

- up to 31 days: daily buckets across the complete window
- longer than 31 days: weekly buckets across the complete window

Operational filtering uses `report_batch_info.process_timestamp`. The external reconciliation section retains its own run date.

## Production integration

Replace the in-memory model in `app.js` with API responses implementing Q001–Q033. Preserve the URL parameters (`days`, `id`, `batch`, `mtcn`, `rule`, `q`, `outcome`, and `future`) so investigation links remain shareable.

Before production release, add authentication and report-group authorization, immutable access/audit logs, API error and evidence-unavailable states, paging for large record sets, service-level age rules for in-progress batches, and a governed export/case-management integration. Do not convert missing journey evidence into a zero count, and do not interpret `is_reported=true` as proof of regulator submission without the downstream owner’s contract.
