# Phase 1 data contract

## Sources

| Source | Phase 1 use |
|---|---|
| `report_transformation_reconciliation` | Authoritative batch controls and KPI counts |
| `record_transformation_journey` | Latest-state record evidence when available |
| `rule_hit` | Rule-hit linkage through `rpt_grp_id + efile_batch_id`; downstream `is_reported` state |
| `rule_hit_exclusion_audit` | Exclusion evidence through `rpt_grp_id + processing_batch_id` |
| `rule_hit_reconciliation` | External aggregate Expected / Matched / Missed control |
| `report_batch_info` | Operational `process_timestamp`, batch lifecycle, compiler outcome, report result |
| `report_group_config` | Country, active flag, versions, and strategy metadata enrichment |

## Control equations

```text
lookback_txn
  = lookback_actual_txn + lookback_future_reporting_txn

reporting_period_txn
  = reporting_period_actual_txn + reporting_period_future_reporting_txn

activity_selected
  = lookback_txn + reporting_period_txn + activity_simulated

actual_reportable_txn is compared with expected_reportable_txn

actual_activity_eligible_for_transformation
  = activity_transformed + activity_transformation_failed

distinct_rule_hits_count_iwra
  = distinct_rule_hits_count_pharos + missed_rule_hits_count_pharos
```

Always calculate and expose a difference rather than assuming a control balances.

## Evidence boundaries

- `duplicate_transformation` is a separate quality signal, not part of the primary transformation equation.
- Future-reporting counts are aggregate timing classifications and are not failures.
- Journey rows are upserted latest-state evidence. Their absence does not change an authoritative aggregate count to zero.
- Rule Hits and Exclusions tabs are conditional on evidence availability.
- `efile_batch_id` proves transformer-batch inclusion. `is_reported` is downstream-owned persisted state and is not proof of regulator submission.
- External reconciliation has independent run-date semantics and is not correlated to transformer batches in Phase 1.
- Missed Rule Hits is aggregate-only and has no transaction-level drilldown.
- `rule_hit_reconciliation_log`, `rule_hit_reconciliation_analysis`, and `unprocessed_rule_hits` are not Phase 1 dependencies.

## Dashboard presentation rules

- Support batch-, transaction-, and rule-first investigation paths that converge on the same evidence.
- A batch view must answer what ran, why it needs attention, and its reported, excluded, failed, future-reporting, and missing-attempt signals.
- A transaction view must answer why it was not reported, its report group, batch, rule, latest stage, future-reporting assessment, and evidence sources.
- A rule view must connect rule-level outcomes to affected batches and transactions.
- Show only the actionable external coverage result (affected groups and aggregate misses) in the operating UI.
- Retain Expected and Matched in SQL as inputs to the reconciliation integrity equation, not as standalone operator cards.
- Use daily trend buckets for windows up to 31 days and weekly buckets for longer windows.
- Every trend must cover the complete selected processing window.
- Do not mix external reconciliation run dates with `report_batch_info.process_timestamp`.
- Do not present Reported, Excluded, Failed, Future Reporting, and Missing Attempts as a linear funnel; their source grains differ.
- Generate an audit explanation from available evidence and explicitly state any evidence gap or downstream boundary.

## Investigation joins

```text
Batch control + lifecycle
  report_transformation_reconciliation
    ↔ report_batch_info
  on rpt_grp_id + batch_id + seq_no

Batch → rule-hit evidence
  report_transformation_reconciliation.batch_id
    ↔ rule_hit.efile_batch_id
  scoped by rpt_grp_id

Batch → exclusion evidence
  report_transformation_reconciliation.batch_id
    ↔ rule_hit_exclusion_audit.processing_batch_id
  scoped by rpt_grp_id

Transaction evidence
  rpt_grp_id + mtcn
  across journey, rule_hit, and exclusion audit where rows exist

Rule evidence
  rpt_grp_id + rule_id
  with affected transformer batches from rule_hit.efile_batch_id
```

The reconciliation strategy metadata controls the logical key grain:

- `TRANSACTION_ONCE`: transaction key
- `TRANSACTION_PER_RULE`: transaction key + rule
- `INTRA_COUNTRY`: transaction key + side

## Health inputs

Keep these distinct in the UI:

- `batch_status`: high-level batch lifecycle.
- `compiler_status`: processing-stage outcome.
- `report_status`: report result classification.
- Derived Health: control differences plus the three execution statuses.

`Generated` does not automatically mean Healthy. `NO_QUALIFIED_TRANSACTIONS` is not automatically a failure.
