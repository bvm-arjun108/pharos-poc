# Conversation-derived Phase 1 schema reference

This reference records the physical table and column names used by the demo SQL. It is intentionally limited to fields established during the code and database validation discussion.

## `report_transformation_reconciliation`

Keys and identity:

- `rpt_grp_id`
- `rpt_grp_name`
- `batch_id`
- `seq_no`
- `created_timestamp`
- `modified_timestamp`

Controls and indicators:

- `expected_reportable_txn`
- `actual_reportable_txn`
- `activity_selected`
- `lookback_txn`
- `lookback_actual_txn`
- `lookback_future_reporting_txn`
- `reporting_period_txn`
- `reporting_period_actual_txn`
- `reporting_period_future_reporting_txn`
- `activity_simulated`
- `actual_activity_eligible_for_transformation`
- `activity_transformed`
- `activity_transformation_failed`
- `duplicate_transformation`
- `txn_missing_attempt_count`
- `already_reported_count`

## `report_batch_info`

- `rpt_grp_id`
- `batch_id`
- `seq_no`
- `process_timestamp`
- `created_timestamp`
- `batch_status`
- `compiler_status`
- `report_status`
- `txn_lookback_start_timestamp`
- `txn_start_timestamp`
- `txn_end_timestamp`

Validated join:

`report_transformation_reconciliation(rpt_grp_id, batch_id, seq_no)`
to
`report_batch_info(rpt_grp_id, batch_id, seq_no)`

## `record_transformation_journey`

- `rpt_grp_id`
- `batch_id`
- `identifier`
- `mtcn`
- `stage`
- `status`
- `comments`
- `created_timestamp`
- `modified_timestamp`

The table is latest-state/upserted evidence rather than complete event history.

## `rule_hit`

- `rpt_grp_id`
- `external_txn_key`
- `rule_id`
- `attempt_id`
- `mtcn`
- `galactic_id`
- `efile_batch_id`
- `is_reported`
- `status`
- `reporting_timestamp`
- `created_timestamp`
- `modified_timestamp`

Validated transformer-batch bridge:

`report_transformation_reconciliation(rpt_grp_id, batch_id)`
to
`rule_hit(rpt_grp_id, efile_batch_id)`

## `rule_hit_exclusion_audit`

- `rpt_grp_id`
- `mtcn`
- `external_txn_key`
- `rule_id`
- `attempt_id`
- `processing_batch_id`
- `reported_batch_id`
- `exclusion_reason_id`
- `exclusion_strategy`
- `reporting_timestamp`
- `created_timestamp`

Validated transformer-batch bridge:

`report_transformation_reconciliation(rpt_grp_id, batch_id)`
to
`rule_hit_exclusion_audit(rpt_grp_id, processing_batch_id)`

## `rule_hit_reconciliation`

- `rpt_grp_id`
- `rpt_grp_name`
- `run_date`
- `seq_no`
- `distinct_rule_hits_count_iwra`
- `distinct_rule_hits_count_pharos`
- `missed_rule_hits_count_pharos`
- `created_timestamp`
- `modified_timestamp`

Validated integrity equation:

`distinct_rule_hits_count_iwra = distinct_rule_hits_count_pharos + missed_rule_hits_count_pharos`

## `report_group_config`

- `rpt_grp_id`
- `rpt_grp_name`
- `country_name`
- `rpt_config_active_flag`
- `transformer_version_id`
- `rpt_selection_version_id`
- `manipulation_strategy_metadata`
- `reconciliation_strategy_metadata`

Configuration enrichment does not replace operational batch evidence.

## Excluded dependencies

The executable Phase 1 SQL contains no references to:

- `rule_hit_reconciliation_log`
- `rule_hit_reconciliation_analysis`
- `unprocessed_rule_hits`

