/* PHAROS PHASE 1 — FINAL POSTGRESQL CATALOG
   Runtime parameters use :from_ts / :to_ts for report_batch_info.process_timestamp.
   External reconciliation uses :from_run_date / :to_run_date independently. */

-- Q001 | Batch and report-group volume
WITH latest AS (
 SELECT DISTINCT ON (r.rpt_grp_id,r.batch_id) r.rpt_grp_id,r.batch_id,r.seq_no,b.process_timestamp
 FROM pharos.report_transformation_reconciliation r JOIN pharos.report_batch_info b USING(rpt_grp_id,batch_id,seq_no)
 WHERE b.process_timestamp>=:from_ts AND b.process_timestamp<:to_ts
 ORDER BY r.rpt_grp_id,r.batch_id,r.seq_no DESC,r.modified_timestamp DESC NULLS LAST)
SELECT COUNT(*) batches_run,COUNT(DISTINCT rpt_grp_id) report_groups_run,
 MIN(process_timestamp) first_process_time,MAX(process_timestamp) last_process_time FROM latest;

-- Q002 | Batches requiring attention
WITH latest AS (
 SELECT DISTINCT ON (r.rpt_grp_id,r.batch_id) r.*,b.process_timestamp,b.batch_status,b.compiler_status,b.report_status
 FROM pharos.report_transformation_reconciliation r JOIN pharos.report_batch_info b USING(rpt_grp_id,batch_id,seq_no)
 WHERE b.process_timestamp>=:from_ts AND b.process_timestamp<:to_ts
 ORDER BY r.rpt_grp_id,r.batch_id,r.seq_no DESC,r.modified_timestamp DESC NULLS LAST)
SELECT *,COALESCE(actual_reportable_txn,0)-COALESCE(expected_reportable_txn,0) reportable_difference,
 COALESCE(activity_transformed,0)+COALESCE(activity_transformation_failed,0)-COALESCE(actual_activity_eligible_for_transformation,0) transformation_difference
FROM latest WHERE batch_status='Failed' OR report_status='FAILED'
 OR COALESCE(actual_reportable_txn,0)<>COALESCE(expected_reportable_txn,0)
 OR COALESCE(activity_transformed,0)+COALESCE(activity_transformation_failed,0)<>COALESCE(actual_activity_eligible_for_transformation,0)
 OR COALESCE(activity_transformation_failed,0)>0 OR COALESCE(txn_missing_attempt_count,0)>0
ORDER BY process_timestamp DESC;

-- Q003 | Transformation failures (aggregate authoritative)
WITH latest AS (
 SELECT DISTINCT ON (r.rpt_grp_id,r.batch_id) r.*,b.process_timestamp
 FROM pharos.report_transformation_reconciliation r JOIN pharos.report_batch_info b USING(rpt_grp_id,batch_id,seq_no)
 WHERE b.process_timestamp>=:from_ts AND b.process_timestamp<:to_ts
 ORDER BY r.rpt_grp_id,r.batch_id,r.seq_no DESC,r.modified_timestamp DESC NULLS LAST)
SELECT SUM(COALESCE(activity_transformation_failed,0)) transformation_failures,
 COUNT(*) FILTER(WHERE COALESCE(activity_transformation_failed,0)>0) affected_batches FROM latest;

-- Q004 | External coverage validation control (aggregate only; UI surfaces misses)
WITH latest AS (
 SELECT DISTINCT ON (rpt_grp_id,run_date) * FROM pharos.rule_hit_reconciliation
 WHERE run_date>=:from_run_date AND run_date<=:to_run_date
 ORDER BY rpt_grp_id,run_date,seq_no DESC,modified_timestamp DESC NULLS LAST)
SELECT SUM(COALESCE(distinct_rule_hits_count_iwra,0)) expected_rule_hits,
 SUM(COALESCE(distinct_rule_hits_count_pharos,0)) matched_rule_hits,
 SUM(COALESCE(missed_rule_hits_count_pharos,0)) missed_rule_hits,
 SUM(COALESCE(distinct_rule_hits_count_iwra,0))-SUM(COALESCE(distinct_rule_hits_count_pharos,0))-SUM(COALESCE(missed_rule_hits_count_pharos,0)) control_difference
FROM latest;

-- Q005 | Actionable report-group health with config enrichment and separate external totals
WITH latest AS (
 SELECT DISTINCT ON (r.rpt_grp_id,r.batch_id) r.*,b.process_timestamp,b.batch_status,b.compiler_status,b.report_status
 FROM pharos.report_transformation_reconciliation r JOIN pharos.report_batch_info b USING(rpt_grp_id,batch_id,seq_no)
 WHERE b.process_timestamp>=:from_ts AND b.process_timestamp<:to_ts
 ORDER BY r.rpt_grp_id,r.batch_id,r.seq_no DESC,r.modified_timestamp DESC NULLS LAST),
operational AS (
 SELECT rpt_grp_id,MAX(rpt_grp_name) rpt_grp_name,COUNT(*) batches,
  COUNT(*) FILTER(WHERE batch_status='Failed' OR report_status='FAILED') failed_batches,
  COUNT(*) FILTER(WHERE COALESCE(actual_reportable_txn,0)<>COALESCE(expected_reportable_txn,0)) reportability_exceptions,
  SUM(COALESCE(activity_transformation_failed,0)) transformation_failures,
  SUM(COALESCE(txn_missing_attempt_count,0)) missing_attempts,
  COUNT(*) FILTER(WHERE report_status='PARTIAL') partial_outputs,
  SUM(COALESCE(duplicate_transformation,0)) duplicate_quality_signal,
  SUM(COALESCE(lookback_future_reporting_txn,0)+COALESCE(reporting_period_future_reporting_txn,0)) future_reporting
 FROM latest GROUP BY rpt_grp_id),
hit_operational AS (
 SELECT l.rpt_grp_id,
  COUNT(DISTINCT rh.external_txn_key) FILTER(WHERE rh.is_reported IS TRUE) reported_transactions,
  COUNT(DISTINCT rh.external_txn_key) FILTER(WHERE rh.is_reported IS FALSE) not_reported_transactions
 FROM latest l JOIN pharos.rule_hit rh
  ON rh.rpt_grp_id=l.rpt_grp_id AND rh.efile_batch_id=l.batch_id
 GROUP BY l.rpt_grp_id),
exclusion_operational AS (
 SELECT l.rpt_grp_id,COUNT(DISTINCT e.external_txn_key) excluded_transactions
 FROM latest l JOIN pharos.rule_hit_exclusion_audit e
  ON e.rpt_grp_id=l.rpt_grp_id AND e.processing_batch_id=l.batch_id
 GROUP BY l.rpt_grp_id),
external_latest AS (
 SELECT DISTINCT ON (rpt_grp_id,run_date) * FROM pharos.rule_hit_reconciliation
 WHERE run_date>=:from_run_date AND run_date<=:to_run_date
 ORDER BY rpt_grp_id,run_date,seq_no DESC,modified_timestamp DESC NULLS LAST),
external AS (
 SELECT rpt_grp_id,SUM(distinct_rule_hits_count_iwra) expected_rule_hits,
  SUM(distinct_rule_hits_count_pharos) matched_rule_hits,SUM(missed_rule_hits_count_pharos) missed_rule_hits
 FROM external_latest GROUP BY rpt_grp_id)
SELECT o.*,COALESCE(h.reported_transactions,0) reported_transactions,
 COALESCE(h.not_reported_transactions,0) not_reported_transactions,
 COALESCE(x.excluded_transactions,0) excluded_transactions,
 c.country_name,c.rpt_config_active_flag,c.transformer_version_id,c.rpt_selection_version_id,
 c.reconciliation_strategy_metadata,e.expected_rule_hits,e.matched_rule_hits,e.missed_rule_hits
FROM operational o LEFT JOIN pharos.report_group_config c
 ON c.rpt_grp_id=o.rpt_grp_id AND c.rpt_config_active_flag IS TRUE
LEFT JOIN hit_operational h USING(rpt_grp_id)
LEFT JOIN exclusion_operational x USING(rpt_grp_id)
LEFT JOIN external e USING(rpt_grp_id)
ORDER BY o.failed_batches DESC,o.reportability_exceptions DESC,o.transformation_failures DESC;

-- Q006 | Priority latest-batch queue with lifecycle statuses
WITH latest AS (
 SELECT DISTINCT ON (r.rpt_grp_id,r.batch_id) r.*,b.process_timestamp,b.batch_status,b.compiler_status,b.report_status
 FROM pharos.report_transformation_reconciliation r JOIN pharos.report_batch_info b USING(rpt_grp_id,batch_id,seq_no)
 WHERE b.process_timestamp>=:from_ts AND b.process_timestamp<:to_ts
 ORDER BY r.rpt_grp_id,r.batch_id,r.seq_no DESC,r.modified_timestamp DESC NULLS LAST)
SELECT rpt_grp_id,rpt_grp_name,batch_id,seq_no,process_timestamp,batch_status,compiler_status,report_status,
 expected_reportable_txn,actual_reportable_txn,txn_missing_attempt_count,activity_transformation_failed,duplicate_transformation
FROM latest
ORDER BY (batch_status='Failed' OR report_status='FAILED') DESC,
 (COALESCE(actual_reportable_txn,0)<>COALESCE(expected_reportable_txn,0)) DESC,process_timestamp DESC;

-- Q007 | Selected report-group external coverage (no batch correlation)
WITH latest AS (
 SELECT DISTINCT ON (rpt_grp_id,run_date) * FROM pharos.rule_hit_reconciliation
 WHERE rpt_grp_id=:rpt_grp_id AND run_date>=:from_run_date AND run_date<=:to_run_date
 ORDER BY rpt_grp_id,run_date,seq_no DESC,modified_timestamp DESC NULLS LAST)
SELECT rpt_grp_id,MAX(rpt_grp_name) rpt_grp_name,SUM(distinct_rule_hits_count_iwra) expected_rule_hits,
 SUM(distinct_rule_hits_count_pharos) matched_rule_hits,SUM(missed_rule_hits_count_pharos) missed_rule_hits
FROM latest GROUP BY rpt_grp_id;

-- Q008 | Selected report-group actionable and supporting indicators
WITH latest AS (
 SELECT DISTINCT ON (r.rpt_grp_id,r.batch_id) r.*,b.batch_status,b.report_status
 FROM pharos.report_transformation_reconciliation r JOIN pharos.report_batch_info b USING(rpt_grp_id,batch_id,seq_no)
 WHERE r.rpt_grp_id=:rpt_grp_id AND b.process_timestamp>=:from_ts AND b.process_timestamp<:to_ts
 ORDER BY r.rpt_grp_id,r.batch_id,r.seq_no DESC,r.modified_timestamp DESC NULLS LAST),
operational AS (
 SELECT COUNT(*) batches,
 COUNT(*) FILTER(WHERE batch_status='Failed' OR report_status='FAILED') failed_batches,
 COUNT(*) FILTER(WHERE COALESCE(actual_reportable_txn,0)<>COALESCE(expected_reportable_txn,0)) reportability_exceptions,
 SUM(COALESCE(txn_missing_attempt_count,0)) missing_attempts,
 SUM(COALESCE(activity_transformation_failed,0)) transformation_failures,
 COUNT(*) FILTER(WHERE report_status='PARTIAL') partial_outputs,
 SUM(COALESCE(duplicate_transformation,0)) duplicate_quality_signal,
 SUM(COALESCE(lookback_future_reporting_txn,0)+COALESCE(reporting_period_future_reporting_txn,0)) future_reporting
 FROM latest),
hit AS (
 SELECT COUNT(DISTINCT rh.external_txn_key) FILTER(WHERE rh.is_reported IS TRUE) reported_transactions,
  COUNT(DISTINCT rh.external_txn_key) FILTER(WHERE rh.is_reported IS FALSE) not_reported_transactions
 FROM latest l JOIN pharos.rule_hit rh
  ON rh.rpt_grp_id=l.rpt_grp_id AND rh.efile_batch_id=l.batch_id),
excluded AS (
 SELECT COUNT(DISTINCT e.external_txn_key) excluded_transactions
 FROM latest l JOIN pharos.rule_hit_exclusion_audit e
  ON e.rpt_grp_id=l.rpt_grp_id AND e.processing_batch_id=l.batch_id)
SELECT o.*,h.reported_transactions,h.not_reported_transactions,e.excluded_transactions
FROM operational o CROSS JOIN hit h CROSS JOIN excluded e;

-- Q009 | Selected report-group latest batch executions
WITH latest AS (
 SELECT DISTINCT ON (r.rpt_grp_id,r.batch_id) r.*,b.process_timestamp,b.batch_status,b.compiler_status,b.report_status
 FROM pharos.report_transformation_reconciliation r JOIN pharos.report_batch_info b USING(rpt_grp_id,batch_id,seq_no)
 WHERE r.rpt_grp_id=:rpt_grp_id AND b.process_timestamp>=:from_ts AND b.process_timestamp<:to_ts
 ORDER BY r.rpt_grp_id,r.batch_id,r.seq_no DESC,r.modified_timestamp DESC NULLS LAST)
SELECT * FROM latest ORDER BY process_timestamp DESC;

-- Q010 | Batch reportability control
SELECT expected_reportable_txn,actual_reportable_txn,
 COALESCE(actual_reportable_txn,0)-COALESCE(expected_reportable_txn,0) difference
FROM pharos.report_transformation_reconciliation
WHERE rpt_grp_id=:rpt_grp_id AND batch_id=:batch_id AND seq_no=:seq_no;

-- Q011 | Batch activity composition and future-reporting aggregates
SELECT activity_selected,lookback_txn,lookback_actual_txn,lookback_future_reporting_txn,
 reporting_period_txn,reporting_period_actual_txn,reporting_period_future_reporting_txn,activity_simulated,
 COALESCE(lookback_actual_txn,0)+COALESCE(lookback_future_reporting_txn,0)-COALESCE(lookback_txn,0) lookback_difference,
 COALESCE(reporting_period_actual_txn,0)+COALESCE(reporting_period_future_reporting_txn,0)-COALESCE(reporting_period_txn,0) reporting_period_difference
FROM pharos.report_transformation_reconciliation
WHERE rpt_grp_id=:rpt_grp_id AND batch_id=:batch_id AND seq_no=:seq_no;

-- Q012 | Primary transformation control; duplicate is separate
SELECT actual_activity_eligible_for_transformation,activity_transformed,activity_transformation_failed,duplicate_transformation,
 COALESCE(activity_transformed,0)+COALESCE(activity_transformation_failed,0)-COALESCE(actual_activity_eligible_for_transformation,0) transformation_difference
FROM pharos.report_transformation_reconciliation
WHERE rpt_grp_id=:rpt_grp_id AND batch_id=:batch_id AND seq_no=:seq_no;

-- Q013 | Batch operational indicators
SELECT txn_missing_attempt_count,already_reported_count,duplicate_transformation,activity_transformation_failed,
 lookback_future_reporting_txn,reporting_period_future_reporting_txn
FROM pharos.report_transformation_reconciliation
WHERE rpt_grp_id=:rpt_grp_id AND batch_id=:batch_id AND seq_no=:seq_no;

-- Q014 | Latest-state journey evidence; may be incomplete relative to aggregates
SELECT identifier,mtcn,stage,status,comments,created_timestamp,modified_timestamp
FROM pharos.record_transformation_journey WHERE rpt_grp_id=:rpt_grp_id AND batch_id=:batch_id
ORDER BY modified_timestamp DESC NULLS LAST,created_timestamp DESC;

-- Q015 | Conditional Rule Hits tab (validated transformer bridge)
SELECT external_txn_key,rule_id,attempt_id,mtcn,efile_batch_id,is_reported,status,
 reporting_timestamp,created_timestamp,modified_timestamp
FROM pharos.rule_hit WHERE rpt_grp_id=:rpt_grp_id AND efile_batch_id=:batch_id
ORDER BY modified_timestamp DESC NULLS LAST,created_timestamp DESC;

-- Q016 | Conditional Exclusions tab (validated transformer bridge)
SELECT mtcn,external_txn_key,rule_id,attempt_id,processing_batch_id,reported_batch_id,
 exclusion_reason_id,exclusion_strategy,reporting_timestamp,created_timestamp
FROM pharos.rule_hit_exclusion_audit WHERE rpt_grp_id=:rpt_grp_id AND processing_batch_id=:batch_id
ORDER BY created_timestamp DESC;

-- Q017 | Transaction latest-state root-cause evidence
SELECT identifier,mtcn,batch_id,stage,status,comments,created_timestamp,modified_timestamp
FROM pharos.record_transformation_journey WHERE rpt_grp_id=:rpt_grp_id AND mtcn=:mtcn
ORDER BY modified_timestamp DESC NULLS LAST,created_timestamp DESC LIMIT 1;

-- Q018 | Transaction identifiers and transformer batch inclusion
SELECT rpt_grp_id,external_txn_key,rule_id,attempt_id,mtcn,galactic_id,efile_batch_id,is_reported
FROM pharos.rule_hit WHERE rpt_grp_id=:rpt_grp_id AND mtcn=:mtcn;

-- Q019 | Latest known processing state (not an event timeline)
SELECT identifier,mtcn,batch_id,stage,status,comments,created_timestamp,modified_timestamp
FROM pharos.record_transformation_journey WHERE rpt_grp_id=:rpt_grp_id AND mtcn=:mtcn
ORDER BY modified_timestamp DESC NULLS LAST,created_timestamp DESC LIMIT 1;

-- Q020 | Transformer output versus downstream persisted reporting state
SELECT rule_id,external_txn_key,mtcn,efile_batch_id,is_reported,status,reporting_timestamp
FROM pharos.rule_hit WHERE rpt_grp_id=:rpt_grp_id AND mtcn=:mtcn;

-- Q021 | Latest batch/compiler/report lifecycle status profile
WITH latest AS (
 SELECT DISTINCT ON (rpt_grp_id,batch_id) rpt_grp_id,batch_id,seq_no,process_timestamp,batch_status,compiler_status,report_status
 FROM pharos.report_batch_info WHERE process_timestamp>=:from_ts AND process_timestamp<:to_ts
 ORDER BY rpt_grp_id,batch_id,seq_no DESC,process_timestamp DESC)
SELECT COALESCE(batch_status,'<NULL>') batch_status,COALESCE(compiler_status,'<NULL>') compiler_status,
 COALESCE(report_status,'<NULL>') report_status,COUNT(*) rows
FROM latest GROUP BY batch_status,compiler_status,report_status ORDER BY rows DESC;

-- Q022 | Evidence-based next-action classification (advisory)
SELECT j.rpt_grp_id,j.batch_id,j.mtcn,j.stage,j.status,j.comments,rh.efile_batch_id,rh.is_reported,
 CASE WHEN j.stage='TRANSFORMATION' AND j.status='FAILURE' THEN 'REPAIR_AND_REPROCESS'
      WHEN j.stage='TRANSACTION_JOIN' AND j.status='ERROR' THEN 'RESOLVE_MISSING_ATTEMPT'
      WHEN rh.efile_batch_id IS NOT NULL AND rh.is_reported IS FALSE THEN 'CHECK_DOWNSTREAM_REPORTING'
      ELSE 'REVIEW_EVIDENCE' END recommended_action
FROM pharos.record_transformation_journey j
LEFT JOIN pharos.rule_hit rh ON rh.rpt_grp_id=j.rpt_grp_id AND rh.mtcn=j.mtcn
WHERE j.rpt_grp_id=:rpt_grp_id AND j.mtcn=:mtcn;

-- Q023 | Adaptive operational trend: daily through 31 days, weekly beyond 31 days
WITH latest AS (
 SELECT DISTINCT ON (r.rpt_grp_id,r.batch_id) r.rpt_grp_id,r.batch_id,r.activity_transformation_failed,
  b.process_timestamp,b.batch_status,b.report_status
 FROM pharos.report_transformation_reconciliation r JOIN pharos.report_batch_info b USING(rpt_grp_id,batch_id,seq_no)
 WHERE b.process_timestamp>=:from_ts AND b.process_timestamp<:to_ts
 ORDER BY r.rpt_grp_id,r.batch_id,r.seq_no DESC,r.modified_timestamp DESC NULLS LAST),
bucketed AS (
 SELECT CASE WHEN CAST(:to_ts AS timestamp)-CAST(:from_ts AS timestamp)<=INTERVAL '31 days'
   THEN DATE_TRUNC('day',process_timestamp) ELSE DATE_TRUNC('week',process_timestamp) END period_bucket,
  batch_status,report_status,activity_transformation_failed
 FROM latest)
SELECT period_bucket,COUNT(*) batches,
 COUNT(*) FILTER(WHERE batch_status='Failed' OR report_status='FAILED') failed_batches,
 SUM(COALESCE(activity_transformation_failed,0)) transformation_failures
FROM bucketed GROUP BY period_bucket ORDER BY period_bucket;

-- Q024 | Report groups with aggregate misses in the external reconciliation run
WITH latest AS (
 SELECT DISTINCT ON (rpt_grp_id,run_date) * FROM pharos.rule_hit_reconciliation
 WHERE run_date>=:from_run_date AND run_date<=:to_run_date
 ORDER BY rpt_grp_id,run_date,seq_no DESC,modified_timestamp DESC NULLS LAST)
SELECT rpt_grp_id,MAX(rpt_grp_name) rpt_grp_name,SUM(distinct_rule_hits_count_iwra) expected_rule_hits,
 SUM(distinct_rule_hits_count_pharos) matched_rule_hits,SUM(missed_rule_hits_count_pharos) missed_rule_hits
FROM latest
GROUP BY rpt_grp_id HAVING SUM(missed_rule_hits_count_pharos)>0 ORDER BY missed_rule_hits DESC;

-- Q025 | Selected batch outcome signals from independent evidence populations
WITH selected_batch AS (
 SELECT r.rpt_grp_id,r.rpt_grp_name,r.batch_id,r.seq_no,b.process_timestamp,
  r.activity_transformation_failed,r.txn_missing_attempt_count,
  COALESCE(r.lookback_future_reporting_txn,0)+COALESCE(r.reporting_period_future_reporting_txn,0) future_reporting
 FROM pharos.report_transformation_reconciliation r
 JOIN pharos.report_batch_info b USING(rpt_grp_id,batch_id,seq_no)
 WHERE r.rpt_grp_id=:rpt_grp_id AND r.batch_id=:batch_id AND r.seq_no=:seq_no),
hit_summary AS (
 SELECT rpt_grp_id,efile_batch_id batch_id,
  COUNT(DISTINCT external_txn_key) linked_transactions,
  COUNT(DISTINCT external_txn_key) FILTER(WHERE is_reported IS TRUE) reported_transactions,
  COUNT(DISTINCT external_txn_key) FILTER(WHERE is_reported IS FALSE) not_reported_transactions
 FROM pharos.rule_hit WHERE rpt_grp_id=:rpt_grp_id AND efile_batch_id=:batch_id
 GROUP BY rpt_grp_id,efile_batch_id),
exclusion_summary AS (
 SELECT rpt_grp_id,processing_batch_id batch_id,
  COUNT(DISTINCT external_txn_key) excluded_transactions
 FROM pharos.rule_hit_exclusion_audit
 WHERE rpt_grp_id=:rpt_grp_id AND processing_batch_id=:batch_id
 GROUP BY rpt_grp_id,processing_batch_id)
SELECT b.*,COALESCE(h.linked_transactions,0) linked_transactions,
 COALESCE(h.reported_transactions,0) reported_transactions,
 COALESCE(h.not_reported_transactions,0) not_reported_transactions,
 COALESCE(e.excluded_transactions,0) excluded_transactions
FROM selected_batch b LEFT JOIN hit_summary h USING(rpt_grp_id,batch_id)
LEFT JOIN exclusion_summary e USING(rpt_grp_id,batch_id);

-- Q026 | Batch transformation-failure reasons with aggregate coverage comparison
WITH authoritative AS (
 SELECT rpt_grp_id,batch_id,seq_no,activity_transformation_failed authoritative_failures
 FROM pharos.report_transformation_reconciliation
 WHERE rpt_grp_id=:rpt_grp_id AND batch_id=:batch_id AND seq_no=:seq_no),
reason_counts AS (
 SELECT rpt_grp_id,batch_id,COALESCE(comments,'Reason not populated') failure_reason,
  COUNT(*) evidence_rows
 FROM pharos.record_transformation_journey
 WHERE rpt_grp_id=:rpt_grp_id AND batch_id=:batch_id
  AND stage='TRANSFORMATION' AND status='FAILURE'
 GROUP BY rpt_grp_id,batch_id,COALESCE(comments,'Reason not populated'))
SELECT a.rpt_grp_id,a.batch_id,a.seq_no,a.authoritative_failures,
 COALESCE(r.failure_reason,'No journey reason evidence') failure_reason,
 COALESCE(r.evidence_rows,0) evidence_rows,
 SUM(COALESCE(r.evidence_rows,0)) OVER() total_reason_evidence_rows
FROM authoritative a LEFT JOIN reason_counts r USING(rpt_grp_id,batch_id)
ORDER BY evidence_rows DESC,failure_reason;

-- Q027 | Rule outcomes linked to a selected transformer batch
SELECT rule_id,COUNT(DISTINCT external_txn_key) linked_transactions,
 COUNT(DISTINCT external_txn_key) FILTER(WHERE is_reported IS TRUE) reported_transactions,
 COUNT(DISTINCT external_txn_key) FILTER(WHERE is_reported IS FALSE) not_reported_transactions,
 COUNT(DISTINCT attempt_id) attempts
FROM pharos.rule_hit
WHERE rpt_grp_id=:rpt_grp_id AND efile_batch_id=:batch_id
GROUP BY rule_id ORDER BY not_reported_transactions DESC,linked_transactions DESC;

-- Q028 | Searchable transaction registry using the latest available evidence
WITH latest_batch AS (
 SELECT DISTINCT ON (rpt_grp_id,batch_id) rpt_grp_id,batch_id,seq_no,process_timestamp
 FROM pharos.report_batch_info
 WHERE process_timestamp>=:from_ts AND process_timestamp<:to_ts
 ORDER BY rpt_grp_id,batch_id,seq_no DESC,process_timestamp DESC),
latest_journey AS (
 SELECT DISTINCT ON (j.rpt_grp_id,j.mtcn) j.rpt_grp_id,j.mtcn,j.batch_id,j.identifier,j.stage,j.status,j.comments,
  j.created_timestamp,j.modified_timestamp
 FROM pharos.record_transformation_journey j
 JOIN latest_batch b ON b.rpt_grp_id=j.rpt_grp_id AND b.batch_id=j.batch_id
 ORDER BY j.rpt_grp_id,j.mtcn,j.modified_timestamp DESC NULLS LAST,j.created_timestamp DESC),
hit AS (
 SELECT rh.rpt_grp_id,rh.mtcn,MIN(rh.external_txn_key) external_txn_key,
  STRING_AGG(DISTINCT rh.rule_id::text,', ' ORDER BY rh.rule_id::text) rule_ids,
  MIN(rh.attempt_id) attempt_id,MIN(rh.galactic_id) galactic_id,MIN(rh.efile_batch_id) efile_batch_id,
  BOOL_OR(rh.is_reported IS TRUE) is_reported,MAX(rh.reporting_timestamp) reporting_timestamp
 FROM pharos.rule_hit rh
 JOIN latest_batch b ON b.rpt_grp_id=rh.rpt_grp_id AND b.batch_id=rh.efile_batch_id
 GROUP BY rh.rpt_grp_id,rh.mtcn),
excluded AS (
 SELECT e.rpt_grp_id,e.mtcn,BOOL_OR(TRUE) is_excluded,
  MAX(e.exclusion_reason_id::text) exclusion_reason,MAX(e.exclusion_strategy::text) exclusion_strategy,
  MAX(e.created_timestamp) exclusion_timestamp
 FROM pharos.rule_hit_exclusion_audit e
 JOIN latest_batch b ON b.rpt_grp_id=e.rpt_grp_id AND b.batch_id=e.processing_batch_id
 GROUP BY e.rpt_grp_id,e.mtcn)
SELECT COALESCE(j.rpt_grp_id,h.rpt_grp_id) rpt_grp_id,COALESCE(j.mtcn,h.mtcn) mtcn,
 COALESCE(j.batch_id,h.efile_batch_id) batch_id,j.identifier,j.stage,j.status,j.comments,
 h.external_txn_key,h.rule_ids,h.attempt_id,h.galactic_id,h.is_reported,h.reporting_timestamp,
 COALESCE(e.is_excluded,FALSE) is_excluded,e.exclusion_reason,e.exclusion_strategy,e.exclusion_timestamp,
 j.modified_timestamp latest_journey_timestamp
FROM latest_journey j FULL OUTER JOIN hit h USING(rpt_grp_id,mtcn)
LEFT JOIN excluded e ON e.rpt_grp_id=COALESCE(j.rpt_grp_id,h.rpt_grp_id)
 AND e.mtcn=COALESCE(j.mtcn,h.mtcn)
ORDER BY COALESCE(j.modified_timestamp,h.reporting_timestamp) DESC NULLS LAST;

-- Q029 | Normalized audit evidence for one transaction
SELECT 'record_transformation_journey' evidence_source,stage evidence_type,status evidence_status,
 comments evidence_detail,batch_id evidence_batch,modified_timestamp evidence_timestamp
FROM pharos.record_transformation_journey
WHERE rpt_grp_id=:rpt_grp_id AND mtcn=:mtcn
UNION ALL
SELECT 'rule_hit','RULE_HIT',CASE WHEN is_reported THEN 'REPORTED' ELSE 'NOT_REPORTED' END,
 CONCAT('rule=',rule_id,', external_txn_key=',external_txn_key),efile_batch_id,modified_timestamp
FROM pharos.rule_hit WHERE rpt_grp_id=:rpt_grp_id AND mtcn=:mtcn
UNION ALL
SELECT 'rule_hit_exclusion_audit','EXCLUSION','EXCLUDED',
 CONCAT('reason=',COALESCE(exclusion_reason_id::text,'Reason not populated'),', strategy=',COALESCE(exclusion_strategy::text,'<NULL>')),
 processing_batch_id,created_timestamp
FROM pharos.rule_hit_exclusion_audit WHERE rpt_grp_id=:rpt_grp_id AND mtcn=:mtcn
ORDER BY evidence_timestamp DESC NULLS LAST;

-- Q030 | Transaction future-reporting assessment when timestamp evidence is available
WITH latest_batch AS (
 SELECT DISTINCT ON (rpt_grp_id,batch_id) rpt_grp_id,batch_id,seq_no,
  txn_lookback_start_timestamp,txn_start_timestamp,txn_end_timestamp
 FROM pharos.report_batch_info
 ORDER BY rpt_grp_id,batch_id,seq_no DESC,process_timestamp DESC)
SELECT rh.rpt_grp_id,rh.mtcn,rh.external_txn_key,rh.rule_id,rh.efile_batch_id,
 rh.created_timestamp,rh.reporting_timestamp,c.reconciliation_strategy_metadata,
 CASE WHEN rh.reporting_timestamp IS NULL OR b.batch_id IS NULL THEN 'EVIDENCE_UNAVAILABLE'
      WHEN DATE(rh.created_timestamp)=DATE(rh.reporting_timestamp) THEN 'NOT_FUTURE_REPORTING'
      WHEN rh.reporting_timestamp>=b.txn_lookback_start_timestamp
       AND rh.reporting_timestamp<b.txn_start_timestamp THEN 'LOOKBACK_FUTURE_REPORTING'
      WHEN rh.reporting_timestamp>=b.txn_start_timestamp
       AND rh.reporting_timestamp<=b.txn_end_timestamp THEN 'REPORTING_PERIOD_FUTURE_REPORTING'
      ELSE 'NOT_FUTURE_REPORTING' END future_reporting_assessment
FROM pharos.rule_hit rh
LEFT JOIN latest_batch b ON b.rpt_grp_id=rh.rpt_grp_id AND b.batch_id=rh.efile_batch_id
LEFT JOIN pharos.report_group_config c
 ON c.rpt_grp_id=rh.rpt_grp_id AND c.rpt_config_active_flag IS TRUE
WHERE rh.rpt_grp_id=:rpt_grp_id AND rh.mtcn=:mtcn;

-- Q031 | Rule explorer summary across linked batches and dispositions
WITH latest_batch AS (
 SELECT DISTINCT ON (rpt_grp_id,batch_id) rpt_grp_id,batch_id,seq_no,process_timestamp
 FROM pharos.report_batch_info
 WHERE process_timestamp>=:from_ts AND process_timestamp<:to_ts
 ORDER BY rpt_grp_id,batch_id,seq_no DESC,process_timestamp DESC),
hit AS (
 SELECT rh.rpt_grp_id,rh.rule_id,COUNT(DISTINCT rh.external_txn_key) linked_transactions,
  COUNT(DISTINCT rh.external_txn_key) FILTER(WHERE rh.is_reported IS TRUE) reported_transactions,
  COUNT(DISTINCT rh.external_txn_key) FILTER(WHERE rh.is_reported IS FALSE) not_reported_transactions,
  COUNT(DISTINCT rh.efile_batch_id) affected_batches
 FROM pharos.rule_hit rh JOIN latest_batch b ON b.rpt_grp_id=rh.rpt_grp_id AND b.batch_id=rh.efile_batch_id
 GROUP BY rh.rpt_grp_id,rh.rule_id),
excluded AS (
 SELECT e.rpt_grp_id,e.rule_id,COUNT(DISTINCT e.external_txn_key) excluded_transactions
 FROM pharos.rule_hit_exclusion_audit e
 JOIN latest_batch b ON b.rpt_grp_id=e.rpt_grp_id AND b.batch_id=e.processing_batch_id
 GROUP BY e.rpt_grp_id,e.rule_id),
failed AS (
 SELECT rh.rpt_grp_id,rh.rule_id,COUNT(DISTINCT j.mtcn) failed_evidence_rows
 FROM pharos.rule_hit rh JOIN latest_batch b ON b.rpt_grp_id=rh.rpt_grp_id AND b.batch_id=rh.efile_batch_id
 JOIN pharos.record_transformation_journey j ON j.rpt_grp_id=rh.rpt_grp_id AND j.mtcn=rh.mtcn
 WHERE j.stage='TRANSFORMATION' AND j.status='FAILURE' GROUP BY rh.rpt_grp_id,rh.rule_id)
SELECT h.*,c.rpt_grp_name,c.country_name,COALESCE(e.excluded_transactions,0) excluded_transactions,
 COALESCE(f.failed_evidence_rows,0) failed_evidence_rows
FROM hit h LEFT JOIN excluded e USING(rpt_grp_id,rule_id)
LEFT JOIN failed f USING(rpt_grp_id,rule_id)
LEFT JOIN pharos.report_group_config c
 ON c.rpt_grp_id=h.rpt_grp_id AND c.rpt_config_active_flag IS TRUE
ORDER BY failed_evidence_rows DESC,not_reported_transactions DESC,linked_transactions DESC;

-- Q032 | Selected rule detail with affected batches and latest transaction evidence
WITH latest_batch AS (
 SELECT DISTINCT ON (rpt_grp_id,batch_id) rpt_grp_id,batch_id,seq_no,process_timestamp,batch_status,report_status
 FROM pharos.report_batch_info
 WHERE process_timestamp>=:from_ts AND process_timestamp<:to_ts
 ORDER BY rpt_grp_id,batch_id,seq_no DESC,process_timestamp DESC),
latest_journey AS (
 SELECT DISTINCT ON (rpt_grp_id,mtcn) rpt_grp_id,mtcn,stage,status,comments,modified_timestamp
 FROM pharos.record_transformation_journey
 ORDER BY rpt_grp_id,mtcn,modified_timestamp DESC NULLS LAST,created_timestamp DESC)
SELECT rh.rpt_grp_id,rh.rule_id,rh.mtcn,rh.external_txn_key,rh.attempt_id,rh.galactic_id,
 rh.efile_batch_id,b.process_timestamp,b.batch_status,b.report_status,rh.is_reported,rh.reporting_timestamp,
 j.stage latest_stage,j.status latest_status,j.comments latest_reason,j.modified_timestamp latest_journey_timestamp
FROM pharos.rule_hit rh
JOIN latest_batch b ON b.rpt_grp_id=rh.rpt_grp_id AND b.batch_id=rh.efile_batch_id
LEFT JOIN latest_journey j ON j.rpt_grp_id=rh.rpt_grp_id AND j.mtcn=rh.mtcn
WHERE rh.rpt_grp_id=:rpt_grp_id AND rh.rule_id=:rule_id
ORDER BY b.process_timestamp DESC,rh.modified_timestamp DESC NULLS LAST;

-- Q033 | Portfolio outcome summary for the selected operating window
WITH latest AS (
 SELECT DISTINCT ON (r.rpt_grp_id,r.batch_id) r.rpt_grp_id,r.batch_id,r.seq_no,
  r.activity_transformation_failed,r.txn_missing_attempt_count,
  r.lookback_future_reporting_txn,r.reporting_period_future_reporting_txn
 FROM pharos.report_transformation_reconciliation r
 JOIN pharos.report_batch_info b USING(rpt_grp_id,batch_id,seq_no)
 WHERE b.process_timestamp>=:from_ts AND b.process_timestamp<:to_ts
 ORDER BY r.rpt_grp_id,r.batch_id,r.seq_no DESC,r.modified_timestamp DESC NULLS LAST),
hit AS (
 SELECT COUNT(DISTINCT (rh.rpt_grp_id,rh.external_txn_key)) FILTER(WHERE rh.is_reported IS TRUE) reported_transactions,
  COUNT(DISTINCT (rh.rpt_grp_id,rh.external_txn_key)) FILTER(WHERE rh.is_reported IS FALSE) not_reported_transactions
 FROM latest l JOIN pharos.rule_hit rh
  ON rh.rpt_grp_id=l.rpt_grp_id AND rh.efile_batch_id=l.batch_id),
excluded AS (
 SELECT COUNT(DISTINCT (e.rpt_grp_id,e.external_txn_key)) excluded_transactions
 FROM latest l JOIN pharos.rule_hit_exclusion_audit e
  ON e.rpt_grp_id=l.rpt_grp_id AND e.processing_batch_id=l.batch_id),
batch_totals AS (
 SELECT COUNT(*) batches,
  SUM(COALESCE(activity_transformation_failed,0)) transformation_failures,
  SUM(COALESCE(txn_missing_attempt_count,0)) missing_attempts,
  SUM(COALESCE(lookback_future_reporting_txn,0)+COALESCE(reporting_period_future_reporting_txn,0)) future_reporting
 FROM latest)
SELECT b.*,h.reported_transactions,h.not_reported_transactions,e.excluded_transactions
FROM batch_totals b CROSS JOIN hit h CROSS JOIN excluded e;
