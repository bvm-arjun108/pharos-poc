# Validation summary

Validated on 19 August 2026 as a self-contained Phase 1 production demo.

## Project integrity

- All 11 HTML pages resolve their local `href` and `src` targets.
- `app.js` and `query-catalog.js` pass JavaScript syntax validation.
- The batch, transaction, rule, report-group, work-queue, and SQL-detail navigation paths are connected.
- Every mock transaction resolves to a known batch, report group, and rule; every rule resolves to known affected batches.
- Demonstration evidence covers reported, excluded, transformation-failed, future-reporting, and downstream-pending cases.
- Batch and transaction audit explanations are generated for every representative record.
- Unavailable Rule Hit or Exclusion evidence is shown explicitly and is not rendered as a zero or as an active drill-down.
- Every representative batch balances the lookback, reporting-period, selected-activity, reportability-difference, and primary transformation equations.
- Displayed report-group reported/excluded totals reconcile to the corresponding portfolio evidence totals in each selectable period.

## Time-window behavior

- The operational trend contains 60 complete daily observations.
- The 7-, 30-, and 60-day totals reconcile to their full selected windows.
- Windows through 31 days render daily; longer windows render weekly.
- Q023 implements the same daily/weekly threshold using `report_batch_info.process_timestamp`.
- External reconciliation retains its independent `run_date` filters.

## SQL catalog

- Q001–Q033 exist in both `queries.sql` and the interactive query catalog.
- Each interactive query matches its source SQL block exactly and ends with a complete statement terminator.
- SQL templates pass static quote and parenthesis balance checks.
- Every HTML query reference resolves to a catalog entry.
- Executable SQL references only the seven approved Phase 1 sources documented in `SCHEMA_REFERENCE.md`.
- Physical column and join references are limited to the conversation-derived schema contract.
- `rule_hit_reconciliation_log`, `rule_hit_reconciliation_analysis`, and `unprocessed_rule_hits` are absent.

## Evidence and presentation rules

- Overview and report-group pages do not present Expected or Matched Rule Hits as operator KPIs.
- External misses remain report-group/run aggregates and have no transaction route.
- Batch controls retain the validated equations; duplicate transformation remains a separate quality signal.
- Rule Hits and Exclusions remain conditional evidence surfaces.
- Transformer-batch inclusion, downstream `is_reported`, and final regulator submission are not conflated.
- Aggregate failure counts remain authoritative when latest-state journey evidence is incomplete.

## Production handoff note

The SQL is a validated PostgreSQL template catalog. Before deployment, bind the named parameters through the application data layer, execute each query against the target schema, inspect query plans and permissions, and add the organization’s audit-retention controls. The static demo intentionally uses representative mock data and performs no live database calls.
