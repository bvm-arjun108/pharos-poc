# Audit evidence guide

## Objective

For any investigated transaction or batch, the dashboard should produce a defensible statement containing:

- the report group and configured reconciliation strategy;
- the transformer batch and latest sequence number;
- the operational processing timestamp and lifecycle statuses;
- the authoritative aggregate control values;
- the latest available record-level state;
- the linked rule and attempt identifiers;
- any exclusion reason and strategy;
- the persisted downstream reported flag;
- the future-reporting assessment and its evidence state;
- the known evidence boundary or unresolved downstream owner.

## What each source proves

| Source | Can prove | Cannot prove alone |
|---|---|---|
| `report_transformation_reconciliation` | Authoritative batch totals and control differences | The individual record behind every aggregate exception |
| `report_batch_info` | Process time and batch/compiler/report lifecycle state | Transaction root cause |
| `record_transformation_journey` | Latest available processing state and comments for a record | Complete event history or guaranteed 1:1 reconstruction of aggregate counts |
| `rule_hit` | Rule linkage, transformer batch inclusion, and persisted `is_reported` state | Final regulator receipt or acceptance |
| `rule_hit_exclusion_audit` | Exclusion reason, strategy, processing batch, and audit timestamp | A reason when the source reason is null |
| `rule_hit_reconciliation` | Aggregate external Expected = Matched + Missed integrity control | A missing transaction list or transformer-batch correlation |

## Standard outcome explanations

### Transformation failure

> The transaction was not reported because its latest available journey evidence shows a transformation failure. The failure reason, report group, transformer batch, rule, and identifiers are retained. The batch aggregate remains authoritative if journey evidence covers only part of the failure population.

### Legitimate exclusion

> The transaction was not reported by this batch because exclusion evidence classifies it as excluded. The explanation must include the exclusion reason and strategy when populated. A null source reason is displayed as “Reason not populated,” never replaced with an invented reason.

### Future reporting

> The transaction is not due in the current reporting window. A positive transaction-level classification is shown only when linked timestamps and the batch window support it. If that evidence is absent, the UI shows “Evidence unavailable” rather than “No.”

### Pending downstream reporting

> Transformation completed and the transaction was included in the transformer batch, but the persisted downstream `is_reported` flag remains false. The Phase 1 evidence cannot establish the downstream cause. The case must be escalated to the downstream reporting owner rather than classified as a transformer failure.

### Marked reported

> The persisted downstream `is_reported` flag is true. This is evidence of downstream reported state, not proof of regulator submission, receipt, or acceptance.

## Evidence gaps

When aggregate and record evidence do not reconcile 1:1, the UI must state:

1. the authoritative aggregate count;
2. the number of available supporting evidence rows;
3. that missing evidence does not reduce the aggregate;
4. which source or system boundary prevents a stronger conclusion.

## Retention and export recommendation

A production implementation should store the copied audit explanation together with query parameters, source-row identifiers, query version, timestamp, user identity, and the batch sequence number. Evidence exports should be immutable or checksum-protected and governed by the organization’s retention policy.

